<?PHP
// Ana fonskiyon dosyası ekleniyor.
include("../../codex.php");

// Güvenlik kontrolü yapılıyor.
if (!isset($_SESSION["user_role"]) and $_SESSION["user_role"] != "admin") {
    header("Location:" . $site_name . "/?status=permission-exist");
    exit();
}


$user_id = $_POST["user_id"];

$users = $db->prepare("UPDATE users SET
user_password=:user_password
WHERE user_id=$user_id");

$update = $users->execute(array(
    'user_password' => md5($_POST["pass_1"])
));


if ($update) {
    header("Location:" . $site_name . "/admin/process.php?type=user_update&user_id=".$_POST["user_id"]);
    exit;
} else {
    header("Location:" . $site_name . "/admin/process.php?type=user_update&user_id=".$_POST["user_id"]);
    exit;
}
