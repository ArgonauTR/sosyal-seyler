<div class="card mb-3">
    <div class="card-header">
        <a href="<?php echo $category_link; ?>" class="text-decoration-none text-muted">
            <h5>
                <i class="bi bi-<?php echo $category_icon; ?> me-1"></i><?php echo $category_title; ?>
            </h5>
        </a>
    </div>
    <div class="card-body">
        <?php echo $category_description; ?>
    </div>
</div>