# MIT Lisansı

**Telif Hakkı (c) 2025 Öğrenci Rehberlik Sistemi**  
Geliştirici: Atakan  
Web Sitesi: [atakan.net.tr](https://atakan.net.tr)

Bu yazılım ve ilgili dokümantasyon dosyaları ("Yazılım") ile ilgili olarak, herhangi bir kişiye, aşağıdaki koşullara tabi olarak, ücretsiz olarak izin verilmektedir:

Yazılımın kopyalarını elde etme, kullanma, değiştirme, birleştirme, yayınlama, dağıtma, alt lisans verme ve/veya satma hakkı tanınır. Ayrıca, Yazılımın sağlandığı kişilere, yukarıdaki haklara uygun olarak Yazılımı kullanma izni verilir, ancak aşağıdaki şartlara uyulması koşuluyla:

1. **Telif Hakkı Bildirimi**: Yukarıdaki telif hakkı bildirimi, geliştirici bilgileri ve bu izin bildirimi, Yazılımın tüm kopyalarında veya önemli kısımlarında yer almalıdır.
2. **Kaynak Kodu Paylaşımı**: Yazılımın değiştirilmiş versiyonları dağıtıldığında, orijinal kaynak koduna atıfta bulunulmalı ve geliştirici sitesi ([atakan.net.tr](https://atakan.net.tr)) belirtilmelidir.
3. **Katkı Bildirimi**: Yazılıma katkı sağlayan kişiler, katkılarıyla ilgili uygun şekilde kredilendirilmelidir. Katkılar için lütfen geliştirici ile iletişime geçin (detaylar için [atakan.net.tr](https://atakan.net.tr)).

**Sorumluluk Reddi**  
YAZILIM, "OLDUĞU GİBİ" SAĞLANMAKTADIR, AÇIK VEYA ZIMNİ HİÇBİR GARANTİ VERİLMEMEKTE, TİCARİ ELVERİŞLİLİK, BELİRLİ BİR AMACA UYGUNLUK VEYA İHLAL ETMEME GARANTİLERİ DAHİL ANCAK BUNLARLA SINIRLI OLMAMAK ÜZERE HİÇBİR GARANTİ SUNULMAMAKTADIR. HİÇBİR DURUMDA, YAZILIMIN YAZARLARI VEYA TELİF HAKKI SAHİPLERİ, YAZILIMIN KULLANIMINDAN VEYA BAŞKA BİR ŞEKİLDE İLİŞKİLİ OLAN, SÖZLEŞME, HAKSIZ FİİL VEYA BAŞKA BİR ŞEKİLDE ORTAYA ÇIKAN HERHANGİ BİR TALEP, ZARAR VEYA DİĞER SORUMLULUKLARDAN DOLAYI SORUMLU TUTULAMAZ.

**İletişim**  
Yazılımla ilgili sorularınız, katkılarınız veya destek talepleriniz için [atakan.net.tr](https://atakan.net.tr) adresinden geliştiriciyle iletişime geçebilirsiniz.

**Ek Not**  
Bu yazılım, açık kaynak bir projedir ve eğitim amaçlı geliştirilmiştir. Kullanıcılar, yazılımı kendi sorumluluklarında kullanmalıdır. Geliştirici, yazılımın kullanımından kaynaklanan herhangi bir veri kaybı veya teknik sorundan sorumlu tutulamaz.