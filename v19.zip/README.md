# Sosyal Şeyler Scripti Nedir?
Boostrap, PHP, MySQL ve JS ile yazılmış forum, sözllük tarzı bir web scriptidir.

# Demo Var mı?
Web Sitemizden bakabilrisiniz. --> https://sosyalseyler.com/

# Nasıl Kurulur?

- Bir veritabanı oluşturun.
- Ana sayfanızı ziyaret edin.
- Veritabanı ve admin bilgilerinizi forma girin.
- Hepsi bu kadar.

# Resimler 
![image](https://github.com/user-attachments/assets/f8832fc0-bd4f-48df-87aa-ba2b69d700a9)


![image](https://github.com/user-attachments/assets/d8407877-2a96-4bd3-a58b-7fa684cbe6c2)

