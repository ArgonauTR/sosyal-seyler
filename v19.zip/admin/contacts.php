<?php
// Ana fonskiyon dosyası ekleniyor.
include("../codex.php");

// Sayfa elemanları ekleniyor.
include("pages/head.php");
include("pages/nav.php");
include("pages/contacts.php");
include("pages/footer.php");

?>