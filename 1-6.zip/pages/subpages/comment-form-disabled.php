    <div class="mb-3">
        <form>
            <div class="mb-3">
                <textarea class="form-control" placeholder="Ne düşünüyosun?" rows="3" required></textarea>
            </div>
            <div class="form-group mt-4 d-grid gap-2 col-6 mx-auto text-center">
                <a href="./login.php" type="submit" class="btn btn-outline-secondary">
                    <i class="bi bi-person"></i> Önce Giriş Yapın
                </a>
            </div>
        </form>
    </div>