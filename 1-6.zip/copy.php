<!doctype html>
<!--

B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B 
 B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B 
B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R
 B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R 
B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O 
 B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B
B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü 
 B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R
B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O
 B Ü R O B Ü R O B Ü R O B Ü R O 
B Ü R O B Ü R O B Ü R O B Ü
 B Ü R O B Ü R O B Ü
B Ü R O B Ü R 
 B Ü R O
B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B 
 B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B 
B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R
 B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R 
B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O 
 B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B
B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü 
 B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O B Ü R
B Ü R O B Ü R O B Ü R O B Ü R O B Ü R O
 B Ü R O B Ü R O B Ü R O B Ü R O 
B Ü R O B Ü R O B Ü R O B Ü
 B Ü R O B Ü R O B Ü
B Ü R O B Ü R 
 B Ü R O                                                        ♥ BY BÜRO: BUROCRATIK.COM
B                                                               YEAR: 2023

-->
<html>

<head>
    <script async defer data-website-id="6c539df8-6a93-4d2d-98f9-8d07f34ef6af" src="https://analytics.madebyburo.com/umami.js"></script>

    <meta data-n-head="ssr" charset="utf-8">
    <meta data-n-head="ssr" name="viewport" content="width=device-width,initial-scale=1">
    <meta data-n-head="ssr" name="format-detection" content="telephone=no">
    <meta data-n-head="ssr" name="google-site-verification" content="csxxuc1fjdLh2r09eEJccix77R7xrxtio8WkNMGVde8">
    <meta data-n-head="ssr" data-hid="charset" charset="utf-8">
    <meta data-n-head="ssr" data-hid="mobile-web-app-capable" name="mobile-web-app-capable" content="yes">
    <meta data-n-head="ssr" data-hid="apple-mobile-web-app-title" name="apple-mobile-web-app-title" content="Grab&Go">
    <meta data-n-head="ssr" data-hid="theme-color" name="theme-color" content="#ff5f00">
    <meta data-n-head="ssr" data-hid="og:type" name="og:type" property="og:type" content="website">
    <meta data-n-head="ssr" data-hid="og:site_name" name="og:site_name" property="og:site_name" content="Grab&Go">
    <meta data-n-head="ssr" data-hid="description" name="description" content="O maior franchising de lojas automáticas da europa, com +200 lojas. Mais de 400 produtos disponíveis, 24h/365 dias.">
    <meta data-n-head="ssr" data-hid="keywords" name="keywords" content="24, 24h, automática, automáticas, baratas, bebidas, comprar, criar, criação, custa, desenvolver, dinheiro, dispensadoras, franchising, franquia, franquias, horas, ideias, investimentos, investir, jofemar, loja, lojas, lucrativas, lucrativo, montar, máquinas, negócio, negócios, oportunidades, picapica, pouco, preços, rentáveis, rentável, snacks, venda, vending">
    <meta data-n-head="ssr" data-hid="og:description" property="og:description" content="O maior franchising de lojas automáticas da europa, com +200 lojas. Mais de 400 produtos disponíveis, 24h/365 dias.">
    <meta data-n-head="ssr" data-hid="og:title" property="og:title" content="Grab&Go — Você descansa, o seu negócio não">
    <meta data-n-head="ssr" data-hid="og:url" property="og:url" content="https://grabandgo.madebyburo.com/">
    <meta data-n-head="ssr" data-hid="og:image" property="og:image" content="https://cdn.sanity.io/images/cfdx00u9/production/ae664a99a2523bd88c95e9d17b469d1d9bd07ba1-1200x630.jpg?w=1200&h=630&auto=format">
    <meta data-n-head="ssr" property="og:image:width" content="1200">
    <meta data-n-head="ssr" property="og:image:height" content="630">
    <meta data-n-head="ssr" data-hid="twitter:card" property="twitter:card" content="summary_large_image">
    <meta data-n-head="ssr" data-hid="twitter:title" property="twitter:title" content="Grab&Go — Você descansa, o seu negócio não">
    <meta data-n-head="ssr" data-hid="twitter:description" property="twitter:description" content="O maior franchising de lojas automáticas da europa, com +200 lojas. Mais de 400 produtos disponíveis, 24h/365 dias.">
    <meta data-n-head="ssr" data-hid="twitter:image" property="twitter:image" content="https://cdn.sanity.io/images/cfdx00u9/production/ae664a99a2523bd88c95e9d17b469d1d9bd07ba1-1200x630.jpg?w=1200&h=630&auto=format">
    <title>Grab&Go</title>
    <link data-n-head="ssr" rel="icon" type="image/png" href="/favicon/favicon_0.png" id="icon">
    <link data-n-head="ssr" data-hid="shortcut-icon" rel="shortcut icon" href="/_nuxt/icons/icon_64x64.9cbf35.png">
    <link data-n-head="ssr" data-hid="apple-touch-icon" rel="apple-touch-icon" href="/_nuxt/icons/icon_512x512.9cbf35.png" sizes="512x512">
    <link data-n-head="ssr" rel="manifest" href="/_nuxt/manifest.7e85e6a4.json" data-hid="manifest">
    <link data-n-head="ssr" rel="canonical" href="https://grabandgo.madebyburo.com/">
    <link rel="preload" href="/_nuxt/f0bf1a6.js" as="script">
    <link rel="preload" href="/_nuxt/d5d45d3.js" as="script">
    <link rel="preload" href="/_nuxt/b529a9c.js" as="script">
    <link rel="preload" href="/_nuxt/bb5d7d3.js" as="script">
    <link rel="preload" href="/_nuxt/4cc0732.js" as="script">
    <link rel="preload" href="/_nuxt/ce6b01c.js" as="script">
    <link rel="preload" href="/_nuxt/dc24a1d.js" as="script">
    <link rel="preload" href="/_nuxt/55a605e.js" as="script">
    <link rel="preload" href="/_nuxt/2f268da.js" as="script">
    <style data-vue-ssr-id="29ddda88:0 0b6c23bf:0 6d713406:0 a65b2fe6:0 7fedf858:0 287efa18:0 4537e23a:0 a0ba878e:0 77d60f5e:0 2b4c22aa:0 2e30db4e:0 1ea8aa68:0 08dbe00f:0 6a774d91:0 6cf9a4d0:0 25bb7514:0 17e3af1a:0 55086a62:0 737115f0:0 5bfff6c0:0 284c4e86:0 7910fd38:0">
        @font-face {
            font-family: vista-black;
            src: url(/fonts/VistaSansBlack.woff2) format("woff2")
        }

        @font-face {
            font-family: vista-med;
            src: url(/fonts/VistaSansMed.woff2) format("woff2")
        }

        @font-face {
            font-family: vista-reg;
            src: url(/fonts/VistaSansReg.woff2) format("woff2")
        }

        :root {
            --self-box-shadow-500: 0px 2px 4px rgba($black, 0.05);
            --self-border-radius-500: max(12px, calc(10.791px + 0.31vw));
            --self-border-radius-300: max(8px, calc(6.791px + 0.31vw))
        }

        @media only screen and (min-width:2000px) {
            :root {
                --self-border-radius-500: max(1px, calc(-4.758px + 1.22vw));
                --self-border-radius-300: max(8px, calc(6.791px + 0.31vw))
            }
        }

        [data-hitarea]:after {
            content: "";
            opacity: 0;
            position: absolute
        }

        [data-hitarea="1"]:after,
        [data-hitarea]:after {
            bottom: -8px;
            left: -8px;
            right: -8px;
            top: -8px
        }

        [data-hitarea="2"]:after {
            bottom: -16px;
            left: -16px;
            right: -16px;
            top: -16px
        }

        [data-hitarea="3"]:after {
            bottom: -24px;
            left: -24px;
            right: -24px;
            top: -24px
        }

        :root {
            --grid-num-cols: 16;
            --grid-max-width: 106.25rem;
            --grid-col-width: 6.25%;
            --grid-padding: max(16px, calc(-6.035px + 5.65vw));
            --grid-gutter: max(2px, calc(-0.964px + 0.76vw));
            --grid-gap: calc(var(--grid-gutter)*2);
            --grid-inset: calc(var(--grid-padding) + var(--grid-gutter));
            --xxlarge: 2000px;
            --xlarge: 1700px;
            --large: 1440px;
            --medium: 1290px;
            --small: 1023px;
            --xsmall: 743px;
            --xxsmall: 413px
        }

        ::-moz-selection {
            background: #000 !important;
            color: #fff !important
        }

        ::selection {
            background: #000 !important;
            color: #fff !important
        }

        body {
            color: #000
        }

        html.lenis {
            height: auto
        }

        .lenis.lenis-smooth {
            scroll-behavior: auto
        }

        .lenis.lenis-smooth [data-lenis-prevent] {
            overscroll-behavior: contain
        }

        span {
            display: inline-block
        }

        a {
            color: inherit
        }

        .-die-safari-die {
            -webkit-mask-image: -webkit-radial-gradient(#fff, #000);
            transform: translateZ(.1);
            will-change: transform
        }

        .-lazy-figure {
            --color-1: #fff;
            --color-2: rgba(0, 0, 0, .4);
            animation: imageLoading 1s ease-in-out infinite;
            animation-direction: alternate;
            background-color: #000;
            background: linear-gradient(-20deg, #fff 10%, rgba(0, 0, 0, .4) 70%, #fff);
            background: linear-gradient(-20deg, var(--color-1) 10%, var(--color-2) 70%, var(--color-1) 100%);
            background-size: 400% 400%
        }

        @keyframes imageLoading {
            0% {
                background-position: 0 0
            }

            to {
                background-position: 0 100%
            }
        }

        * {
            -webkit-tap-highlight-color: transparent
        }

        .shade {
            background-color: #000;
            height: 100vh;
            left: 0;
            opacity: 0;
            pointer-events: none;
            position: fixed;
            top: 0;
            transition: opacity .3s ease;
            width: 100vw;
            z-index: 22
        }

        .shade.open {
            opacity: .4;
            pointer-events: all
        }

        .show-mobile {
            display: none !important
        }

        @media only screen and (max-width:1023px) {
            .show-mobile {
                display: block !important
            }

            .hide-mobile {
                display: none !important
            }
        }

        .-h1 {
            font-family: vista-black;
            font-size: max(56px, calc(19.067px + 9.47vw));
            font-weight: 100 !important;
            letter-spacing: -.06em;
            line-height: .9em
        }

        @media only screen and (min-width:2000px) {
            .-h1 {
                font-size: max(1px, calc(-49.998px + 12.82vw))
            }
        }

        .-h2 {
            font-family: vista-black;
            font-size: max(48px, calc(26.55px + 5.5vw));
            font-weight: 100 !important;
            letter-spacing: -.06em;
            line-height: 1em
        }

        @media only screen and (min-width:2000px) {
            .-h2 {
                font-size: max(1px, calc(-35.724px + 9.16vw))
            }
        }

        @media only screen and (max-width:1023px) {
            .-h2 {
                line-height: .9em
            }
        }

        .-h3 {
            font-family: vista-black;
            font-size: max(40px, calc(28.105px + 3.05vw));
            font-weight: 100;
            letter-spacing: -.06em;
            line-height: 1.1em
        }

        @media only screen and (min-width:2000px) {
            .-h3 {
                font-size: max(1px, calc(-22.62px + 5.8vw))
            }
        }

        .-h4 {
            font-family: vista-black;
            font-size: max(32px, calc(22.484px + 2.44vw));
            font-weight: 100;
            letter-spacing: -.06em;
            line-height: 1em
        }

        @media only screen and (min-width:2000px) {
            .-h4 {
                font-size: max(1px, calc(-22.035px + 5.65vw))
            }
        }

        @media only screen and (max-width:1023px) {
            .-h4 {
                line-height: 1.2em
            }
        }

        .-h5 {
            font-family: vista-med;
            font-size: max(28px, calc(22.033px + 1.53vw));
            font-weight: 100;
            letter-spacing: -.06em;
            line-height: 1em
        }

        @media only screen and (min-width:2000px) {
            .-h5 {
                font-size: max(1px, calc(-17.277px + 4.43vw))
            }
        }

        .-h6 {
            font-family: vista-med;
            font-size: max(24px, calc(20.412px + .92vw));
            font-weight: 100;
            letter-spacing: -.04em;
            line-height: 1em
        }

        @media only screen and (min-width:2000px) {
            .-h6 {
                font-size: max(1px, calc(-8.931px + 2.29vw))
            }
        }

        @media only screen and (max-width:1023px) {
            .-h6 {
                line-height: 1.3em
            }
        }

        .-h7 {
            font-family: vista-med;
            font-size: max(20px, calc(16.412px + .92vw));
            font-weight: 100;
            letter-spacing: -.06em;
            line-height: 1.3em
        }

        @media only screen and (min-width:2000px) {
            .-h7 {
                font-size: max(1px, calc(-12.519px + 3.21vw))
            }
        }

        @media only screen and (max-width:1023px) {
            .-h7 {
                letter-spacing: -.01em
            }
        }

        .-subtitle {
            font-family: vista-med;
            font-size: max(20px, calc(18.791px + .31vw));
            font-weight: 100;
            letter-spacing: -.04em;
            line-height: 1.35em
        }

        @media only screen and (min-width:2000px) {
            .-subtitle {
                font-size: 1.4117647059vw
            }
        }

        .-body {
            font-family: vista-reg;
            font-size: 16px;
            font-weight: 100;
            letter-spacing: -.04em;
            line-height: 1.5em
        }

        @media only screen and (min-width:2000px) {
            .-body {
                font-size: .9411764706vw
            }
        }

        .-caption {
            font-size: 12px;
            letter-spacing: -.04em
        }

        .-caption,
        .-label {
            font-family: vista-reg;
            font-weight: 100;
            line-height: 1.5em
        }

        .-label {
            font-size: 10px;
            letter-spacing: -.02em
        }

        .-text-center {
            text-align: center
        }

        .-capitalize {
            text-transform: capitalize
        }

        .-uppercase {
            text-transform: uppercase
        }

        .-no-scrollbar {
            -ms-overflow-style: none;
            scrollbar-width: none
        }

        .-no-scrollbar::-webkit-scrollbar {
            display: none
        }

        .bg-texture:before {
            mix-blend-mode: color-burn;
            opacity: .3
        }

        .bg-texture-orange:before,
        .bg-texture:before {
            background: url(/pattern.webp) repeat, #f6c97d;
            background-size: 30%;
            content: " ";
            display: block;
            height: 100%;
            left: 0;
            pointer-events: none;
            position: absolute;
            top: 0;
            width: 100%
        }

        .bg-texture-orange:before {
            mix-blend-mode: soft-light;
            opacity: .2;
            will-change: transform
        }

        :root {
            --computed-100vh: 100vh;
            --native-scrollbar-width: 0px;
            --computed-100vw: calc(100vw - var(--native-scrollbar-width))
        }

        body,
        html {
            -webkit-overflow-scrolling: touch;
            -webkit-font-smoothing: antialiased;
            color: #000;
            min-height: 100%;
            text-rendering: optimizeLegibility;
            width: 100%
        }

        *,
        :after,
        :before {
            box-sizing: border-box
        }

        .-noselect {
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -moz-user-select: none;
            user-select: none
        }

        .-hidden-input {
            clip: rect(0 0 0 0);
            -webkit-clip-path: inset(50%);
            clip-path: inset(50%);
            height: 1px;
            overflow: hidden;
            position: absolute;
            white-space: nowrap;
            width: 1px
        }

        img {
            -webkit-user-drag: none;
            -moz-user-drag: none;
            display: block;
            height: auto;
            max-width: 100%;
            -webkit-user-select: none;
            -moz-user-select: none;
            user-select: none
        }

        .block-bg-cover {
            height: 100%;
            left: 0;
            overflow: hidden;
            position: absolute;
            top: 0;
            width: 100%;
            z-index: 0
        }

        .block-bg-cover .element-cover {
            display: block;
            height: 100%;
            -o-object-fit: cover;
            object-fit: cover;
            -o-object-position: 50% 50%;
            object-position: 50% 50%;
            overflow: hidden;
            position: relative;
            width: 100%
        }

        button {
            background: 0 0;
            border: none;
            border-radius: 0;
            cursor: pointer;
            margin: 0;
            outline: 0;
            padding: 0;
            position: relative
        }

        a {
            -webkit-text-decoration: none;
            text-decoration: none
        }

        a,
        abbr,
        acronym,
        address,
        applet,
        article,
        aside,
        audio,
        b,
        big,
        blockquote,
        body,
        canvas,
        caption,
        center,
        cite,
        code,
        dd,
        del,
        details,
        dfn,
        div,
        dl,
        dt,
        em,
        embed,
        fieldset,
        figcaption,
        figure,
        footer,
        form,
        h1,
        h2,
        h3,
        h4,
        h5,
        h6,
        header,
        hgroup,
        html,
        i,
        iframe,
        img,
        ins,
        kbd,
        label,
        legend,
        li,
        mark,
        menu,
        nav,
        object,
        ol,
        output,
        p,
        pre,
        q,
        ruby,
        s,
        samp,
        section,
        small,
        span,
        strike,
        strong,
        sub,
        summary,
        sup,
        table,
        tbody,
        td,
        tfoot,
        th,
        thead,
        time,
        tr,
        tt,
        u,
        ul,
        var,
        video {
            border: 0;
            font-size: 100%;
            margin: 0;
            padding: 0;
            vertical-align: baseline
        }

        :focus {
            outline: 0
        }

        article,
        aside,
        details,
        figcaption,
        figure,
        footer,
        header,
        hgroup,
        menu,
        nav,
        section {
            display: block
        }

        body {
            line-height: 1
        }

        ol,
        ul {
            list-style: none
        }

        blockquote,
        q {
            quotes: none
        }

        blockquote:after,
        blockquote:before,
        q:after,
        q:before {
            content: "";
            content: none
        }

        input[type=search]::-webkit-search-cancel-button,
        input[type=search]::-webkit-search-decoration,
        input[type=search]::-webkit-search-results-button,
        input[type=search]::-webkit-search-results-decoration {
            -webkit-appearance: none;
            -moz-appearance: none
        }

        input[type=search] {
            -webkit-appearance: none;
            -moz-appearance: none
        }

        audio,
        canvas,
        video {
            display: inline-block;
            max-width: 100%
        }

        audio:not([controls]) {
            display: none;
            height: 0
        }

        [hidden] {
            display: none
        }

        html {
            -webkit-text-size-adjust: 100%;
            -ms-text-size-adjust: 100%;
            font-size: 100%
        }

        a:focus {
            outline: thin dotted;
            outline: 0
        }

        a:active,
        a:hover {
            outline: 0
        }

        img {
            -ms-interpolation-mode: bicubic;
            border: 0
        }

        figure,
        form {
            margin: 0
        }

        fieldset {
            border: 1px solid silver;
            margin: 0 2px;
            padding: .35em .625em .75em
        }

        legend {
            border: 0;
            padding: 0;
            white-space: normal
        }

        button,
        input,
        select,
        textarea {
            font-size: 100%;
            margin: 0;
            vertical-align: baseline
        }

        button,
        input {
            line-height: normal
        }

        button,
        select {
            text-transform: none
        }

        button,
        html input[type=button],
        input[type=reset],
        input[type=submit] {
            -webkit-appearance: button;
            cursor: pointer
        }

        button[disabled],
        html input[disabled] {
            cursor: default
        }

        input[type=checkbox],
        input[type=radio] {
            box-sizing: border-box;
            padding: 0
        }

        input[type=search] {
            -webkit-appearance: textfield;
            box-sizing: content-box
        }

        input[type=search]::-webkit-search-cancel-button,
        input[type=search]::-webkit-search-decoration {
            -webkit-appearance: none
        }

        button::-moz-focus-inner,
        input::-moz-focus-inner {
            border: 0;
            padding: 0
        }

        textarea {
            overflow: auto;
            vertical-align: top
        }

        table {
            border-collapse: collapse;
            border-spacing: 0
        }

        button,
        html,
        input,
        select,
        textarea {
            color: #222
        }

        ::-moz-selection {
            -webkit-text-fill-color: #fff;
            background: #105df1;
            color: #fff;
            text-shadow: none
        }

        ::selection {
            -webkit-text-fill-color: #fff;
            background: #105df1;
            color: #fff;
            text-shadow: none
        }

        img {
            vertical-align: middle
        }

        fieldset {
            border: 0;
            margin: 0;
            padding: 0
        }

        textarea {
            resize: vertical
        }

        .chromeframe {
            background: #ccc;
            color: #000;
            margin: .2em 0;
            padding: .2em 0
        }

        .row {
            display: flex;
            flex-flow: row wrap;
            margin-left: auto;
            margin-right: auto;
            max-width: none;
            padding-left: max(16px, calc(-6.035px + 5.65vw));
            padding-left: var(--grid-padding);
            padding-right: max(16px, calc(-6.035px + 5.65vw));
            padding-right: var(--grid-padding);
            width: 100%
        }

        .row.fixed {
            max-width: 106.25rem
        }

        .row.collapse>.col,
        .row.collapse>.column,
        .row.collapse>.columns {
            padding-left: 0;
            padding-right: 0
        }

        .col,
        .column,
        .columns {
            flex: 1 1 0px;
            min-width: 0;
            min-width: auto;
            padding-left: max(2px, calc(-.964px + .76vw));
            padding-left: var(--grid-gutter);
            padding-right: max(2px, calc(-.964px + .76vw));
            padding-right: var(--grid-gutter)
        }

        .xxlarge-1 {
            flex: 0 0 6.25%;
            max-width: 6.25%
        }

        .xxlarge-offset-0 {
            margin-left: 0
        }

        .xxlarge-order-1 {
            order: 1
        }

        .xxlarge-up-1 {
            flex-wrap: wrap
        }

        .xxlarge-up-1>.column,
        .xxlarge-up-1>.columns {
            flex: 0 0 100%;
            max-width: 100%
        }

        .xxlarge-2 {
            flex: 0 0 12.5%;
            max-width: 12.5%
        }

        .xxlarge-offset-1 {
            margin-left: 6.25%
        }

        .xxlarge-order-2 {
            order: 2
        }

        .xxlarge-up-2 {
            flex-wrap: wrap
        }

        .xxlarge-up-2>.column,
        .xxlarge-up-2>.columns {
            flex: 0 0 50%;
            max-width: 50%
        }

        .xxlarge-3 {
            flex: 0 0 18.75%;
            max-width: 18.75%
        }

        .xxlarge-offset-2 {
            margin-left: 12.5%
        }

        .xxlarge-order-3 {
            order: 3
        }

        .xxlarge-up-3 {
            flex-wrap: wrap
        }

        .xxlarge-up-3>.column,
        .xxlarge-up-3>.columns {
            flex: 0 0 33.3333333333%;
            max-width: 33.3333333333%
        }

        .xxlarge-4 {
            flex: 0 0 25%;
            max-width: 25%
        }

        .xxlarge-offset-3 {
            margin-left: 18.75%
        }

        .xxlarge-order-4 {
            order: 4
        }

        .xxlarge-up-4 {
            flex-wrap: wrap
        }

        .xxlarge-up-4>.column,
        .xxlarge-up-4>.columns {
            flex: 0 0 25%;
            max-width: 25%
        }

        .xxlarge-5 {
            flex: 0 0 31.25%;
            max-width: 31.25%
        }

        .xxlarge-offset-4 {
            margin-left: 25%
        }

        .xxlarge-order-5 {
            order: 5
        }

        .xxlarge-up-5 {
            flex-wrap: wrap
        }

        .xxlarge-up-5>.column,
        .xxlarge-up-5>.columns {
            flex: 0 0 20%;
            max-width: 20%
        }

        .xxlarge-6 {
            flex: 0 0 37.5%;
            max-width: 37.5%
        }

        .xxlarge-offset-5 {
            margin-left: 31.25%
        }

        .xxlarge-order-6 {
            order: 6
        }

        .xxlarge-up-6 {
            flex-wrap: wrap
        }

        .xxlarge-up-6>.column,
        .xxlarge-up-6>.columns {
            flex: 0 0 16.6666666667%;
            max-width: 16.6666666667%
        }

        .xxlarge-7 {
            flex: 0 0 43.75%;
            max-width: 43.75%
        }

        .xxlarge-offset-6 {
            margin-left: 37.5%
        }

        .xxlarge-order-7 {
            order: 7
        }

        .xxlarge-up-7 {
            flex-wrap: wrap
        }

        .xxlarge-up-7>.column,
        .xxlarge-up-7>.columns {
            flex: 0 0 14.2857142857%;
            max-width: 14.2857142857%
        }

        .xxlarge-8 {
            flex: 0 0 50%;
            max-width: 50%
        }

        .xxlarge-offset-7 {
            margin-left: 43.75%
        }

        .xxlarge-order-8 {
            order: 8
        }

        .xxlarge-up-8 {
            flex-wrap: wrap
        }

        .xxlarge-up-8>.column,
        .xxlarge-up-8>.columns {
            flex: 0 0 12.5%;
            max-width: 12.5%
        }

        .xxlarge-9 {
            flex: 0 0 56.25%;
            max-width: 56.25%
        }

        .xxlarge-offset-8 {
            margin-left: 50%
        }

        .xxlarge-order-9 {
            order: 9
        }

        .xxlarge-up-9 {
            flex-wrap: wrap
        }

        .xxlarge-up-9>.column,
        .xxlarge-up-9>.columns {
            flex: 0 0 11.1111111111%;
            max-width: 11.1111111111%
        }

        .xxlarge-10 {
            flex: 0 0 62.5%;
            max-width: 62.5%
        }

        .xxlarge-offset-9 {
            margin-left: 56.25%
        }

        .xxlarge-order-10 {
            order: 10
        }

        .xxlarge-up-10 {
            flex-wrap: wrap
        }

        .xxlarge-up-10>.column,
        .xxlarge-up-10>.columns {
            flex: 0 0 10%;
            max-width: 10%
        }

        .xxlarge-11 {
            flex: 0 0 68.75%;
            max-width: 68.75%
        }

        .xxlarge-offset-10 {
            margin-left: 62.5%
        }

        .xxlarge-order-11 {
            order: 11
        }

        .xxlarge-up-11 {
            flex-wrap: wrap
        }

        .xxlarge-up-11>.column,
        .xxlarge-up-11>.columns {
            flex: 0 0 9.0909090909%;
            max-width: 9.0909090909%
        }

        .xxlarge-12 {
            flex: 0 0 75%;
            max-width: 75%
        }

        .xxlarge-offset-11 {
            margin-left: 68.75%
        }

        .xxlarge-order-12 {
            order: 12
        }

        .xxlarge-up-12 {
            flex-wrap: wrap
        }

        .xxlarge-up-12>.column,
        .xxlarge-up-12>.columns {
            flex: 0 0 8.3333333333%;
            max-width: 8.3333333333%
        }

        .xxlarge-13 {
            flex: 0 0 81.25%;
            max-width: 81.25%
        }

        .xxlarge-offset-12 {
            margin-left: 75%
        }

        .xxlarge-order-13 {
            order: 13
        }

        .xxlarge-up-13 {
            flex-wrap: wrap
        }

        .xxlarge-up-13>.column,
        .xxlarge-up-13>.columns {
            flex: 0 0 7.6923076923%;
            max-width: 7.6923076923%
        }

        .xxlarge-14 {
            flex: 0 0 87.5%;
            max-width: 87.5%
        }

        .xxlarge-offset-13 {
            margin-left: 81.25%
        }

        .xxlarge-order-14 {
            order: 14
        }

        .xxlarge-up-14 {
            flex-wrap: wrap
        }

        .xxlarge-up-14>.column,
        .xxlarge-up-14>.columns {
            flex: 0 0 7.1428571429%;
            max-width: 7.1428571429%
        }

        .xxlarge-15 {
            flex: 0 0 93.75%;
            max-width: 93.75%
        }

        .xxlarge-offset-14 {
            margin-left: 87.5%
        }

        .xxlarge-order-15 {
            order: 15
        }

        .xxlarge-up-15 {
            flex-wrap: wrap
        }

        .xxlarge-up-15>.column,
        .xxlarge-up-15>.columns {
            flex: 0 0 6.6666666667%;
            max-width: 6.6666666667%
        }

        .xxlarge-16 {
            flex: 0 0 100%;
            max-width: 100%
        }

        .xxlarge-offset-15 {
            margin-left: 93.75%
        }

        .xxlarge-order-16 {
            order: 16
        }

        .xxlarge-up-16 {
            flex-wrap: wrap
        }

        .xxlarge-up-16>.column,
        .xxlarge-up-16>.columns {
            flex: 0 0 6.25%;
            max-width: 6.25%
        }

        @media screen and (max-width:1700px) {
            .xlarge-1 {
                flex: 0 0 6.25%;
                max-width: 6.25%
            }

            .xlarge-offset-0 {
                margin-left: 0
            }

            .xlarge-order-1 {
                order: 1
            }

            .xlarge-up-1 {
                flex-wrap: wrap
            }

            .xlarge-up-1>.column,
            .xlarge-up-1>.columns {
                flex: 0 0 100%;
                max-width: 100%
            }

            .xlarge-2 {
                flex: 0 0 12.5%;
                max-width: 12.5%
            }

            .xlarge-offset-1 {
                margin-left: 6.25%
            }

            .xlarge-order-2 {
                order: 2
            }

            .xlarge-up-2 {
                flex-wrap: wrap
            }

            .xlarge-up-2>.column,
            .xlarge-up-2>.columns {
                flex: 0 0 50%;
                max-width: 50%
            }

            .xlarge-3 {
                flex: 0 0 18.75%;
                max-width: 18.75%
            }

            .xlarge-offset-2 {
                margin-left: 12.5%
            }

            .xlarge-order-3 {
                order: 3
            }

            .xlarge-up-3 {
                flex-wrap: wrap
            }

            .xlarge-up-3>.column,
            .xlarge-up-3>.columns {
                flex: 0 0 33.3333333333%;
                max-width: 33.3333333333%
            }

            .xlarge-4 {
                flex: 0 0 25%;
                max-width: 25%
            }

            .xlarge-offset-3 {
                margin-left: 18.75%
            }

            .xlarge-order-4 {
                order: 4
            }

            .xlarge-up-4 {
                flex-wrap: wrap
            }

            .xlarge-up-4>.column,
            .xlarge-up-4>.columns {
                flex: 0 0 25%;
                max-width: 25%
            }

            .xlarge-5 {
                flex: 0 0 31.25%;
                max-width: 31.25%
            }

            .xlarge-offset-4 {
                margin-left: 25%
            }

            .xlarge-order-5 {
                order: 5
            }

            .xlarge-up-5 {
                flex-wrap: wrap
            }

            .xlarge-up-5>.column,
            .xlarge-up-5>.columns {
                flex: 0 0 20%;
                max-width: 20%
            }

            .xlarge-6 {
                flex: 0 0 37.5%;
                max-width: 37.5%
            }

            .xlarge-offset-5 {
                margin-left: 31.25%
            }

            .xlarge-order-6 {
                order: 6
            }

            .xlarge-up-6 {
                flex-wrap: wrap
            }

            .xlarge-up-6>.column,
            .xlarge-up-6>.columns {
                flex: 0 0 16.6666666667%;
                max-width: 16.6666666667%
            }

            .xlarge-7 {
                flex: 0 0 43.75%;
                max-width: 43.75%
            }

            .xlarge-offset-6 {
                margin-left: 37.5%
            }

            .xlarge-order-7 {
                order: 7
            }

            .xlarge-up-7 {
                flex-wrap: wrap
            }

            .xlarge-up-7>.column,
            .xlarge-up-7>.columns {
                flex: 0 0 14.2857142857%;
                max-width: 14.2857142857%
            }

            .xlarge-8 {
                flex: 0 0 50%;
                max-width: 50%
            }

            .xlarge-offset-7 {
                margin-left: 43.75%
            }

            .xlarge-order-8 {
                order: 8
            }

            .xlarge-up-8 {
                flex-wrap: wrap
            }

            .xlarge-up-8>.column,
            .xlarge-up-8>.columns {
                flex: 0 0 12.5%;
                max-width: 12.5%
            }

            .xlarge-9 {
                flex: 0 0 56.25%;
                max-width: 56.25%
            }

            .xlarge-offset-8 {
                margin-left: 50%
            }

            .xlarge-order-9 {
                order: 9
            }

            .xlarge-up-9 {
                flex-wrap: wrap
            }

            .xlarge-up-9>.column,
            .xlarge-up-9>.columns {
                flex: 0 0 11.1111111111%;
                max-width: 11.1111111111%
            }

            .xlarge-10 {
                flex: 0 0 62.5%;
                max-width: 62.5%
            }

            .xlarge-offset-9 {
                margin-left: 56.25%
            }

            .xlarge-order-10 {
                order: 10
            }

            .xlarge-up-10 {
                flex-wrap: wrap
            }

            .xlarge-up-10>.column,
            .xlarge-up-10>.columns {
                flex: 0 0 10%;
                max-width: 10%
            }

            .xlarge-11 {
                flex: 0 0 68.75%;
                max-width: 68.75%
            }

            .xlarge-offset-10 {
                margin-left: 62.5%
            }

            .xlarge-order-11 {
                order: 11
            }

            .xlarge-up-11 {
                flex-wrap: wrap
            }

            .xlarge-up-11>.column,
            .xlarge-up-11>.columns {
                flex: 0 0 9.0909090909%;
                max-width: 9.0909090909%
            }

            .xlarge-12 {
                flex: 0 0 75%;
                max-width: 75%
            }

            .xlarge-offset-11 {
                margin-left: 68.75%
            }

            .xlarge-order-12 {
                order: 12
            }

            .xlarge-up-12 {
                flex-wrap: wrap
            }

            .xlarge-up-12>.column,
            .xlarge-up-12>.columns {
                flex: 0 0 8.3333333333%;
                max-width: 8.3333333333%
            }

            .xlarge-13 {
                flex: 0 0 81.25%;
                max-width: 81.25%
            }

            .xlarge-offset-12 {
                margin-left: 75%
            }

            .xlarge-order-13 {
                order: 13
            }

            .xlarge-up-13 {
                flex-wrap: wrap
            }

            .xlarge-up-13>.column,
            .xlarge-up-13>.columns {
                flex: 0 0 7.6923076923%;
                max-width: 7.6923076923%
            }

            .xlarge-14 {
                flex: 0 0 87.5%;
                max-width: 87.5%
            }

            .xlarge-offset-13 {
                margin-left: 81.25%
            }

            .xlarge-order-14 {
                order: 14
            }

            .xlarge-up-14 {
                flex-wrap: wrap
            }

            .xlarge-up-14>.column,
            .xlarge-up-14>.columns {
                flex: 0 0 7.1428571429%;
                max-width: 7.1428571429%
            }

            .xlarge-15 {
                flex: 0 0 93.75%;
                max-width: 93.75%
            }

            .xlarge-offset-14 {
                margin-left: 87.5%
            }

            .xlarge-order-15 {
                order: 15
            }

            .xlarge-up-15 {
                flex-wrap: wrap
            }

            .xlarge-up-15>.column,
            .xlarge-up-15>.columns {
                flex: 0 0 6.6666666667%;
                max-width: 6.6666666667%
            }

            .xlarge-16 {
                flex: 0 0 100%;
                max-width: 100%
            }

            .xlarge-offset-15 {
                margin-left: 93.75%
            }

            .xlarge-order-16 {
                order: 16
            }

            .xlarge-up-16 {
                flex-wrap: wrap
            }

            .xlarge-up-16>.column,
            .xlarge-up-16>.columns {
                flex: 0 0 6.25%;
                max-width: 6.25%
            }
        }

        @media screen and (max-width:1440px) {
            .large-1 {
                flex: 0 0 6.25%;
                max-width: 6.25%
            }

            .large-offset-0 {
                margin-left: 0
            }

            .large-order-1 {
                order: 1
            }

            .large-up-1 {
                flex-wrap: wrap
            }

            .large-up-1>.column,
            .large-up-1>.columns {
                flex: 0 0 100%;
                max-width: 100%
            }

            .large-2 {
                flex: 0 0 12.5%;
                max-width: 12.5%
            }

            .large-offset-1 {
                margin-left: 6.25%
            }

            .large-order-2 {
                order: 2
            }

            .large-up-2 {
                flex-wrap: wrap
            }

            .large-up-2>.column,
            .large-up-2>.columns {
                flex: 0 0 50%;
                max-width: 50%
            }

            .large-3 {
                flex: 0 0 18.75%;
                max-width: 18.75%
            }

            .large-offset-2 {
                margin-left: 12.5%
            }

            .large-order-3 {
                order: 3
            }

            .large-up-3 {
                flex-wrap: wrap
            }

            .large-up-3>.column,
            .large-up-3>.columns {
                flex: 0 0 33.3333333333%;
                max-width: 33.3333333333%
            }

            .large-4 {
                flex: 0 0 25%;
                max-width: 25%
            }

            .large-offset-3 {
                margin-left: 18.75%
            }

            .large-order-4 {
                order: 4
            }

            .large-up-4 {
                flex-wrap: wrap
            }

            .large-up-4>.column,
            .large-up-4>.columns {
                flex: 0 0 25%;
                max-width: 25%
            }

            .large-5 {
                flex: 0 0 31.25%;
                max-width: 31.25%
            }

            .large-offset-4 {
                margin-left: 25%
            }

            .large-order-5 {
                order: 5
            }

            .large-up-5 {
                flex-wrap: wrap
            }

            .large-up-5>.column,
            .large-up-5>.columns {
                flex: 0 0 20%;
                max-width: 20%
            }

            .large-6 {
                flex: 0 0 37.5%;
                max-width: 37.5%
            }

            .large-offset-5 {
                margin-left: 31.25%
            }

            .large-order-6 {
                order: 6
            }

            .large-up-6 {
                flex-wrap: wrap
            }

            .large-up-6>.column,
            .large-up-6>.columns {
                flex: 0 0 16.6666666667%;
                max-width: 16.6666666667%
            }

            .large-7 {
                flex: 0 0 43.75%;
                max-width: 43.75%
            }

            .large-offset-6 {
                margin-left: 37.5%
            }

            .large-order-7 {
                order: 7
            }

            .large-up-7 {
                flex-wrap: wrap
            }

            .large-up-7>.column,
            .large-up-7>.columns {
                flex: 0 0 14.2857142857%;
                max-width: 14.2857142857%
            }

            .large-8 {
                flex: 0 0 50%;
                max-width: 50%
            }

            .large-offset-7 {
                margin-left: 43.75%
            }

            .large-order-8 {
                order: 8
            }

            .large-up-8 {
                flex-wrap: wrap
            }

            .large-up-8>.column,
            .large-up-8>.columns {
                flex: 0 0 12.5%;
                max-width: 12.5%
            }

            .large-9 {
                flex: 0 0 56.25%;
                max-width: 56.25%
            }

            .large-offset-8 {
                margin-left: 50%
            }

            .large-order-9 {
                order: 9
            }

            .large-up-9 {
                flex-wrap: wrap
            }

            .large-up-9>.column,
            .large-up-9>.columns {
                flex: 0 0 11.1111111111%;
                max-width: 11.1111111111%
            }

            .large-10 {
                flex: 0 0 62.5%;
                max-width: 62.5%
            }

            .large-offset-9 {
                margin-left: 56.25%
            }

            .large-order-10 {
                order: 10
            }

            .large-up-10 {
                flex-wrap: wrap
            }

            .large-up-10>.column,
            .large-up-10>.columns {
                flex: 0 0 10%;
                max-width: 10%
            }

            .large-11 {
                flex: 0 0 68.75%;
                max-width: 68.75%
            }

            .large-offset-10 {
                margin-left: 62.5%
            }

            .large-order-11 {
                order: 11
            }

            .large-up-11 {
                flex-wrap: wrap
            }

            .large-up-11>.column,
            .large-up-11>.columns {
                flex: 0 0 9.0909090909%;
                max-width: 9.0909090909%
            }

            .large-12 {
                flex: 0 0 75%;
                max-width: 75%
            }

            .large-offset-11 {
                margin-left: 68.75%
            }

            .large-order-12 {
                order: 12
            }

            .large-up-12 {
                flex-wrap: wrap
            }

            .large-up-12>.column,
            .large-up-12>.columns {
                flex: 0 0 8.3333333333%;
                max-width: 8.3333333333%
            }

            .large-13 {
                flex: 0 0 81.25%;
                max-width: 81.25%
            }

            .large-offset-12 {
                margin-left: 75%
            }

            .large-order-13 {
                order: 13
            }

            .large-up-13 {
                flex-wrap: wrap
            }

            .large-up-13>.column,
            .large-up-13>.columns {
                flex: 0 0 7.6923076923%;
                max-width: 7.6923076923%
            }

            .large-14 {
                flex: 0 0 87.5%;
                max-width: 87.5%
            }

            .large-offset-13 {
                margin-left: 81.25%
            }

            .large-order-14 {
                order: 14
            }

            .large-up-14 {
                flex-wrap: wrap
            }

            .large-up-14>.column,
            .large-up-14>.columns {
                flex: 0 0 7.1428571429%;
                max-width: 7.1428571429%
            }

            .large-15 {
                flex: 0 0 93.75%;
                max-width: 93.75%
            }

            .large-offset-14 {
                margin-left: 87.5%
            }

            .large-order-15 {
                order: 15
            }

            .large-up-15 {
                flex-wrap: wrap
            }

            .large-up-15>.column,
            .large-up-15>.columns {
                flex: 0 0 6.6666666667%;
                max-width: 6.6666666667%
            }

            .large-16 {
                flex: 0 0 100%;
                max-width: 100%
            }

            .large-offset-15 {
                margin-left: 93.75%
            }

            .large-order-16 {
                order: 16
            }

            .large-up-16 {
                flex-wrap: wrap
            }

            .large-up-16>.column,
            .large-up-16>.columns {
                flex: 0 0 6.25%;
                max-width: 6.25%
            }
        }

        @media screen and (max-width:1290px) {
            .medium-1 {
                flex: 0 0 6.25%;
                max-width: 6.25%
            }

            .medium-offset-0 {
                margin-left: 0
            }

            .medium-order-1 {
                order: 1
            }

            .medium-up-1 {
                flex-wrap: wrap
            }

            .medium-up-1>.column,
            .medium-up-1>.columns {
                flex: 0 0 100%;
                max-width: 100%
            }

            .medium-2 {
                flex: 0 0 12.5%;
                max-width: 12.5%
            }

            .medium-offset-1 {
                margin-left: 6.25%
            }

            .medium-order-2 {
                order: 2
            }

            .medium-up-2 {
                flex-wrap: wrap
            }

            .medium-up-2>.column,
            .medium-up-2>.columns {
                flex: 0 0 50%;
                max-width: 50%
            }

            .medium-3 {
                flex: 0 0 18.75%;
                max-width: 18.75%
            }

            .medium-offset-2 {
                margin-left: 12.5%
            }

            .medium-order-3 {
                order: 3
            }

            .medium-up-3 {
                flex-wrap: wrap
            }

            .medium-up-3>.column,
            .medium-up-3>.columns {
                flex: 0 0 33.3333333333%;
                max-width: 33.3333333333%
            }

            .medium-4 {
                flex: 0 0 25%;
                max-width: 25%
            }

            .medium-offset-3 {
                margin-left: 18.75%
            }

            .medium-order-4 {
                order: 4
            }

            .medium-up-4 {
                flex-wrap: wrap
            }

            .medium-up-4>.column,
            .medium-up-4>.columns {
                flex: 0 0 25%;
                max-width: 25%
            }

            .medium-5 {
                flex: 0 0 31.25%;
                max-width: 31.25%
            }

            .medium-offset-4 {
                margin-left: 25%
            }

            .medium-order-5 {
                order: 5
            }

            .medium-up-5 {
                flex-wrap: wrap
            }

            .medium-up-5>.column,
            .medium-up-5>.columns {
                flex: 0 0 20%;
                max-width: 20%
            }

            .medium-6 {
                flex: 0 0 37.5%;
                max-width: 37.5%
            }

            .medium-offset-5 {
                margin-left: 31.25%
            }

            .medium-order-6 {
                order: 6
            }

            .medium-up-6 {
                flex-wrap: wrap
            }

            .medium-up-6>.column,
            .medium-up-6>.columns {
                flex: 0 0 16.6666666667%;
                max-width: 16.6666666667%
            }

            .medium-7 {
                flex: 0 0 43.75%;
                max-width: 43.75%
            }

            .medium-offset-6 {
                margin-left: 37.5%
            }

            .medium-order-7 {
                order: 7
            }

            .medium-up-7 {
                flex-wrap: wrap
            }

            .medium-up-7>.column,
            .medium-up-7>.columns {
                flex: 0 0 14.2857142857%;
                max-width: 14.2857142857%
            }

            .medium-8 {
                flex: 0 0 50%;
                max-width: 50%
            }

            .medium-offset-7 {
                margin-left: 43.75%
            }

            .medium-order-8 {
                order: 8
            }

            .medium-up-8 {
                flex-wrap: wrap
            }

            .medium-up-8>.column,
            .medium-up-8>.columns {
                flex: 0 0 12.5%;
                max-width: 12.5%
            }

            .medium-9 {
                flex: 0 0 56.25%;
                max-width: 56.25%
            }

            .medium-offset-8 {
                margin-left: 50%
            }

            .medium-order-9 {
                order: 9
            }

            .medium-up-9 {
                flex-wrap: wrap
            }

            .medium-up-9>.column,
            .medium-up-9>.columns {
                flex: 0 0 11.1111111111%;
                max-width: 11.1111111111%
            }

            .medium-10 {
                flex: 0 0 62.5%;
                max-width: 62.5%
            }

            .medium-offset-9 {
                margin-left: 56.25%
            }

            .medium-order-10 {
                order: 10
            }

            .medium-up-10 {
                flex-wrap: wrap
            }

            .medium-up-10>.column,
            .medium-up-10>.columns {
                flex: 0 0 10%;
                max-width: 10%
            }

            .medium-11 {
                flex: 0 0 68.75%;
                max-width: 68.75%
            }

            .medium-offset-10 {
                margin-left: 62.5%
            }

            .medium-order-11 {
                order: 11
            }

            .medium-up-11 {
                flex-wrap: wrap
            }

            .medium-up-11>.column,
            .medium-up-11>.columns {
                flex: 0 0 9.0909090909%;
                max-width: 9.0909090909%
            }

            .medium-12 {
                flex: 0 0 75%;
                max-width: 75%
            }

            .medium-offset-11 {
                margin-left: 68.75%
            }

            .medium-order-12 {
                order: 12
            }

            .medium-up-12 {
                flex-wrap: wrap
            }

            .medium-up-12>.column,
            .medium-up-12>.columns {
                flex: 0 0 8.3333333333%;
                max-width: 8.3333333333%
            }

            .medium-13 {
                flex: 0 0 81.25%;
                max-width: 81.25%
            }

            .medium-offset-12 {
                margin-left: 75%
            }

            .medium-order-13 {
                order: 13
            }

            .medium-up-13 {
                flex-wrap: wrap
            }

            .medium-up-13>.column,
            .medium-up-13>.columns {
                flex: 0 0 7.6923076923%;
                max-width: 7.6923076923%
            }

            .medium-14 {
                flex: 0 0 87.5%;
                max-width: 87.5%
            }

            .medium-offset-13 {
                margin-left: 81.25%
            }

            .medium-order-14 {
                order: 14
            }

            .medium-up-14 {
                flex-wrap: wrap
            }

            .medium-up-14>.column,
            .medium-up-14>.columns {
                flex: 0 0 7.1428571429%;
                max-width: 7.1428571429%
            }

            .medium-15 {
                flex: 0 0 93.75%;
                max-width: 93.75%
            }

            .medium-offset-14 {
                margin-left: 87.5%
            }

            .medium-order-15 {
                order: 15
            }

            .medium-up-15 {
                flex-wrap: wrap
            }

            .medium-up-15>.column,
            .medium-up-15>.columns {
                flex: 0 0 6.6666666667%;
                max-width: 6.6666666667%
            }

            .medium-16 {
                flex: 0 0 100%;
                max-width: 100%
            }

            .medium-offset-15 {
                margin-left: 93.75%
            }

            .medium-order-16 {
                order: 16
            }

            .medium-up-16 {
                flex-wrap: wrap
            }

            .medium-up-16>.column,
            .medium-up-16>.columns {
                flex: 0 0 6.25%;
                max-width: 6.25%
            }
        }

        @media screen and (max-width:1023px) {
            .small-1 {
                flex: 0 0 6.25%;
                max-width: 6.25%
            }

            .small-offset-0 {
                margin-left: 0
            }

            .small-order-1 {
                order: 1
            }

            .small-up-1 {
                flex-wrap: wrap
            }

            .small-up-1>.column,
            .small-up-1>.columns {
                flex: 0 0 100%;
                max-width: 100%
            }

            .small-2 {
                flex: 0 0 12.5%;
                max-width: 12.5%
            }

            .small-offset-1 {
                margin-left: 6.25%
            }

            .small-order-2 {
                order: 2
            }

            .small-up-2 {
                flex-wrap: wrap
            }

            .small-up-2>.column,
            .small-up-2>.columns {
                flex: 0 0 50%;
                max-width: 50%
            }

            .small-3 {
                flex: 0 0 18.75%;
                max-width: 18.75%
            }

            .small-offset-2 {
                margin-left: 12.5%
            }

            .small-order-3 {
                order: 3
            }

            .small-up-3 {
                flex-wrap: wrap
            }

            .small-up-3>.column,
            .small-up-3>.columns {
                flex: 0 0 33.3333333333%;
                max-width: 33.3333333333%
            }

            .small-4 {
                flex: 0 0 25%;
                max-width: 25%
            }

            .small-offset-3 {
                margin-left: 18.75%
            }

            .small-order-4 {
                order: 4
            }

            .small-up-4 {
                flex-wrap: wrap
            }

            .small-up-4>.column,
            .small-up-4>.columns {
                flex: 0 0 25%;
                max-width: 25%
            }

            .small-5 {
                flex: 0 0 31.25%;
                max-width: 31.25%
            }

            .small-offset-4 {
                margin-left: 25%
            }

            .small-order-5 {
                order: 5
            }

            .small-up-5 {
                flex-wrap: wrap
            }

            .small-up-5>.column,
            .small-up-5>.columns {
                flex: 0 0 20%;
                max-width: 20%
            }

            .small-6 {
                flex: 0 0 37.5%;
                max-width: 37.5%
            }

            .small-offset-5 {
                margin-left: 31.25%
            }

            .small-order-6 {
                order: 6
            }

            .small-up-6 {
                flex-wrap: wrap
            }

            .small-up-6>.column,
            .small-up-6>.columns {
                flex: 0 0 16.6666666667%;
                max-width: 16.6666666667%
            }

            .small-7 {
                flex: 0 0 43.75%;
                max-width: 43.75%
            }

            .small-offset-6 {
                margin-left: 37.5%
            }

            .small-order-7 {
                order: 7
            }

            .small-up-7 {
                flex-wrap: wrap
            }

            .small-up-7>.column,
            .small-up-7>.columns {
                flex: 0 0 14.2857142857%;
                max-width: 14.2857142857%
            }

            .small-8 {
                flex: 0 0 50%;
                max-width: 50%
            }

            .small-offset-7 {
                margin-left: 43.75%
            }

            .small-order-8 {
                order: 8
            }

            .small-up-8 {
                flex-wrap: wrap
            }

            .small-up-8>.column,
            .small-up-8>.columns {
                flex: 0 0 12.5%;
                max-width: 12.5%
            }

            .small-9 {
                flex: 0 0 56.25%;
                max-width: 56.25%
            }

            .small-offset-8 {
                margin-left: 50%
            }

            .small-order-9 {
                order: 9
            }

            .small-up-9 {
                flex-wrap: wrap
            }

            .small-up-9>.column,
            .small-up-9>.columns {
                flex: 0 0 11.1111111111%;
                max-width: 11.1111111111%
            }

            .small-10 {
                flex: 0 0 62.5%;
                max-width: 62.5%
            }

            .small-offset-9 {
                margin-left: 56.25%
            }

            .small-order-10 {
                order: 10
            }

            .small-up-10 {
                flex-wrap: wrap
            }

            .small-up-10>.column,
            .small-up-10>.columns {
                flex: 0 0 10%;
                max-width: 10%
            }

            .small-11 {
                flex: 0 0 68.75%;
                max-width: 68.75%
            }

            .small-offset-10 {
                margin-left: 62.5%
            }

            .small-order-11 {
                order: 11
            }

            .small-up-11 {
                flex-wrap: wrap
            }

            .small-up-11>.column,
            .small-up-11>.columns {
                flex: 0 0 9.0909090909%;
                max-width: 9.0909090909%
            }

            .small-12 {
                flex: 0 0 75%;
                max-width: 75%
            }

            .small-offset-11 {
                margin-left: 68.75%
            }

            .small-order-12 {
                order: 12
            }

            .small-up-12 {
                flex-wrap: wrap
            }

            .small-up-12>.column,
            .small-up-12>.columns {
                flex: 0 0 8.3333333333%;
                max-width: 8.3333333333%
            }

            .small-13 {
                flex: 0 0 81.25%;
                max-width: 81.25%
            }

            .small-offset-12 {
                margin-left: 75%
            }

            .small-order-13 {
                order: 13
            }

            .small-up-13 {
                flex-wrap: wrap
            }

            .small-up-13>.column,
            .small-up-13>.columns {
                flex: 0 0 7.6923076923%;
                max-width: 7.6923076923%
            }

            .small-14 {
                flex: 0 0 87.5%;
                max-width: 87.5%
            }

            .small-offset-13 {
                margin-left: 81.25%
            }

            .small-order-14 {
                order: 14
            }

            .small-up-14 {
                flex-wrap: wrap
            }

            .small-up-14>.column,
            .small-up-14>.columns {
                flex: 0 0 7.1428571429%;
                max-width: 7.1428571429%
            }

            .small-15 {
                flex: 0 0 93.75%;
                max-width: 93.75%
            }

            .small-offset-14 {
                margin-left: 87.5%
            }

            .small-order-15 {
                order: 15
            }

            .small-up-15 {
                flex-wrap: wrap
            }

            .small-up-15>.column,
            .small-up-15>.columns {
                flex: 0 0 6.6666666667%;
                max-width: 6.6666666667%
            }

            .small-16 {
                flex: 0 0 100%;
                max-width: 100%
            }

            .small-offset-15 {
                margin-left: 93.75%
            }

            .small-order-16 {
                order: 16
            }

            .small-up-16 {
                flex-wrap: wrap
            }

            .small-up-16>.column,
            .small-up-16>.columns {
                flex: 0 0 6.25%;
                max-width: 6.25%
            }
        }

        @media screen and (max-width:743px) {
            .xsmall-1 {
                flex: 0 0 6.25%;
                max-width: 6.25%
            }

            .xsmall-offset-0 {
                margin-left: 0
            }

            .xsmall-order-1 {
                order: 1
            }

            .xsmall-up-1 {
                flex-wrap: wrap
            }

            .xsmall-up-1>.column,
            .xsmall-up-1>.columns {
                flex: 0 0 100%;
                max-width: 100%
            }

            .xsmall-2 {
                flex: 0 0 12.5%;
                max-width: 12.5%
            }

            .xsmall-offset-1 {
                margin-left: 6.25%
            }

            .xsmall-order-2 {
                order: 2
            }

            .xsmall-up-2 {
                flex-wrap: wrap
            }

            .xsmall-up-2>.column,
            .xsmall-up-2>.columns {
                flex: 0 0 50%;
                max-width: 50%
            }

            .xsmall-3 {
                flex: 0 0 18.75%;
                max-width: 18.75%
            }

            .xsmall-offset-2 {
                margin-left: 12.5%
            }

            .xsmall-order-3 {
                order: 3
            }

            .xsmall-up-3 {
                flex-wrap: wrap
            }

            .xsmall-up-3>.column,
            .xsmall-up-3>.columns {
                flex: 0 0 33.3333333333%;
                max-width: 33.3333333333%
            }

            .xsmall-4 {
                flex: 0 0 25%;
                max-width: 25%
            }

            .xsmall-offset-3 {
                margin-left: 18.75%
            }

            .xsmall-order-4 {
                order: 4
            }

            .xsmall-up-4 {
                flex-wrap: wrap
            }

            .xsmall-up-4>.column,
            .xsmall-up-4>.columns {
                flex: 0 0 25%;
                max-width: 25%
            }

            .xsmall-5 {
                flex: 0 0 31.25%;
                max-width: 31.25%
            }

            .xsmall-offset-4 {
                margin-left: 25%
            }

            .xsmall-order-5 {
                order: 5
            }

            .xsmall-up-5 {
                flex-wrap: wrap
            }

            .xsmall-up-5>.column,
            .xsmall-up-5>.columns {
                flex: 0 0 20%;
                max-width: 20%
            }

            .xsmall-6 {
                flex: 0 0 37.5%;
                max-width: 37.5%
            }

            .xsmall-offset-5 {
                margin-left: 31.25%
            }

            .xsmall-order-6 {
                order: 6
            }

            .xsmall-up-6 {
                flex-wrap: wrap
            }

            .xsmall-up-6>.column,
            .xsmall-up-6>.columns {
                flex: 0 0 16.6666666667%;
                max-width: 16.6666666667%
            }

            .xsmall-7 {
                flex: 0 0 43.75%;
                max-width: 43.75%
            }

            .xsmall-offset-6 {
                margin-left: 37.5%
            }

            .xsmall-order-7 {
                order: 7
            }

            .xsmall-up-7 {
                flex-wrap: wrap
            }

            .xsmall-up-7>.column,
            .xsmall-up-7>.columns {
                flex: 0 0 14.2857142857%;
                max-width: 14.2857142857%
            }

            .xsmall-8 {
                flex: 0 0 50%;
                max-width: 50%
            }

            .xsmall-offset-7 {
                margin-left: 43.75%
            }

            .xsmall-order-8 {
                order: 8
            }

            .xsmall-up-8 {
                flex-wrap: wrap
            }

            .xsmall-up-8>.column,
            .xsmall-up-8>.columns {
                flex: 0 0 12.5%;
                max-width: 12.5%
            }

            .xsmall-9 {
                flex: 0 0 56.25%;
                max-width: 56.25%
            }

            .xsmall-offset-8 {
                margin-left: 50%
            }

            .xsmall-order-9 {
                order: 9
            }

            .xsmall-up-9 {
                flex-wrap: wrap
            }

            .xsmall-up-9>.column,
            .xsmall-up-9>.columns {
                flex: 0 0 11.1111111111%;
                max-width: 11.1111111111%
            }

            .xsmall-10 {
                flex: 0 0 62.5%;
                max-width: 62.5%
            }

            .xsmall-offset-9 {
                margin-left: 56.25%
            }

            .xsmall-order-10 {
                order: 10
            }

            .xsmall-up-10 {
                flex-wrap: wrap
            }

            .xsmall-up-10>.column,
            .xsmall-up-10>.columns {
                flex: 0 0 10%;
                max-width: 10%
            }

            .xsmall-11 {
                flex: 0 0 68.75%;
                max-width: 68.75%
            }

            .xsmall-offset-10 {
                margin-left: 62.5%
            }

            .xsmall-order-11 {
                order: 11
            }

            .xsmall-up-11 {
                flex-wrap: wrap
            }

            .xsmall-up-11>.column,
            .xsmall-up-11>.columns {
                flex: 0 0 9.0909090909%;
                max-width: 9.0909090909%
            }

            .xsmall-12 {
                flex: 0 0 75%;
                max-width: 75%
            }

            .xsmall-offset-11 {
                margin-left: 68.75%
            }

            .xsmall-order-12 {
                order: 12
            }

            .xsmall-up-12 {
                flex-wrap: wrap
            }

            .xsmall-up-12>.column,
            .xsmall-up-12>.columns {
                flex: 0 0 8.3333333333%;
                max-width: 8.3333333333%
            }

            .xsmall-13 {
                flex: 0 0 81.25%;
                max-width: 81.25%
            }

            .xsmall-offset-12 {
                margin-left: 75%
            }

            .xsmall-order-13 {
                order: 13
            }

            .xsmall-up-13 {
                flex-wrap: wrap
            }

            .xsmall-up-13>.column,
            .xsmall-up-13>.columns {
                flex: 0 0 7.6923076923%;
                max-width: 7.6923076923%
            }

            .xsmall-14 {
                flex: 0 0 87.5%;
                max-width: 87.5%
            }

            .xsmall-offset-13 {
                margin-left: 81.25%
            }

            .xsmall-order-14 {
                order: 14
            }

            .xsmall-up-14 {
                flex-wrap: wrap
            }

            .xsmall-up-14>.column,
            .xsmall-up-14>.columns {
                flex: 0 0 7.1428571429%;
                max-width: 7.1428571429%
            }

            .xsmall-15 {
                flex: 0 0 93.75%;
                max-width: 93.75%
            }

            .xsmall-offset-14 {
                margin-left: 87.5%
            }

            .xsmall-order-15 {
                order: 15
            }

            .xsmall-up-15 {
                flex-wrap: wrap
            }

            .xsmall-up-15>.column,
            .xsmall-up-15>.columns {
                flex: 0 0 6.6666666667%;
                max-width: 6.6666666667%
            }

            .xsmall-16 {
                flex: 0 0 100%;
                max-width: 100%
            }

            .xsmall-offset-15 {
                margin-left: 93.75%
            }

            .xsmall-order-16 {
                order: 16
            }

            .xsmall-up-16 {
                flex-wrap: wrap
            }

            .xsmall-up-16>.column,
            .xsmall-up-16>.columns {
                flex: 0 0 6.25%;
                max-width: 6.25%
            }
        }

        @media screen and (max-width:413px) {
            .xxsmall-1 {
                flex: 0 0 6.25%;
                max-width: 6.25%
            }

            .xxsmall-offset-0 {
                margin-left: 0
            }

            .xxsmall-order-1 {
                order: 1
            }

            .xxsmall-up-1 {
                flex-wrap: wrap
            }

            .xxsmall-up-1>.column,
            .xxsmall-up-1>.columns {
                flex: 0 0 100%;
                max-width: 100%
            }

            .xxsmall-2 {
                flex: 0 0 12.5%;
                max-width: 12.5%
            }

            .xxsmall-offset-1 {
                margin-left: 6.25%
            }

            .xxsmall-order-2 {
                order: 2
            }

            .xxsmall-up-2 {
                flex-wrap: wrap
            }

            .xxsmall-up-2>.column,
            .xxsmall-up-2>.columns {
                flex: 0 0 50%;
                max-width: 50%
            }

            .xxsmall-3 {
                flex: 0 0 18.75%;
                max-width: 18.75%
            }

            .xxsmall-offset-2 {
                margin-left: 12.5%
            }

            .xxsmall-order-3 {
                order: 3
            }

            .xxsmall-up-3 {
                flex-wrap: wrap
            }

            .xxsmall-up-3>.column,
            .xxsmall-up-3>.columns {
                flex: 0 0 33.3333333333%;
                max-width: 33.3333333333%
            }

            .xxsmall-4 {
                flex: 0 0 25%;
                max-width: 25%
            }

            .xxsmall-offset-3 {
                margin-left: 18.75%
            }

            .xxsmall-order-4 {
                order: 4
            }

            .xxsmall-up-4 {
                flex-wrap: wrap
            }

            .xxsmall-up-4>.column,
            .xxsmall-up-4>.columns {
                flex: 0 0 25%;
                max-width: 25%
            }

            .xxsmall-5 {
                flex: 0 0 31.25%;
                max-width: 31.25%
            }

            .xxsmall-offset-4 {
                margin-left: 25%
            }

            .xxsmall-order-5 {
                order: 5
            }

            .xxsmall-up-5 {
                flex-wrap: wrap
            }

            .xxsmall-up-5>.column,
            .xxsmall-up-5>.columns {
                flex: 0 0 20%;
                max-width: 20%
            }

            .xxsmall-6 {
                flex: 0 0 37.5%;
                max-width: 37.5%
            }

            .xxsmall-offset-5 {
                margin-left: 31.25%
            }

            .xxsmall-order-6 {
                order: 6
            }

            .xxsmall-up-6 {
                flex-wrap: wrap
            }

            .xxsmall-up-6>.column,
            .xxsmall-up-6>.columns {
                flex: 0 0 16.6666666667%;
                max-width: 16.6666666667%
            }

            .xxsmall-7 {
                flex: 0 0 43.75%;
                max-width: 43.75%
            }

            .xxsmall-offset-6 {
                margin-left: 37.5%
            }

            .xxsmall-order-7 {
                order: 7
            }

            .xxsmall-up-7 {
                flex-wrap: wrap
            }

            .xxsmall-up-7>.column,
            .xxsmall-up-7>.columns {
                flex: 0 0 14.2857142857%;
                max-width: 14.2857142857%
            }

            .xxsmall-8 {
                flex: 0 0 50%;
                max-width: 50%
            }

            .xxsmall-offset-7 {
                margin-left: 43.75%
            }

            .xxsmall-order-8 {
                order: 8
            }

            .xxsmall-up-8 {
                flex-wrap: wrap
            }

            .xxsmall-up-8>.column,
            .xxsmall-up-8>.columns {
                flex: 0 0 12.5%;
                max-width: 12.5%
            }

            .xxsmall-9 {
                flex: 0 0 56.25%;
                max-width: 56.25%
            }

            .xxsmall-offset-8 {
                margin-left: 50%
            }

            .xxsmall-order-9 {
                order: 9
            }

            .xxsmall-up-9 {
                flex-wrap: wrap
            }

            .xxsmall-up-9>.column,
            .xxsmall-up-9>.columns {
                flex: 0 0 11.1111111111%;
                max-width: 11.1111111111%
            }

            .xxsmall-10 {
                flex: 0 0 62.5%;
                max-width: 62.5%
            }

            .xxsmall-offset-9 {
                margin-left: 56.25%
            }

            .xxsmall-order-10 {
                order: 10
            }

            .xxsmall-up-10 {
                flex-wrap: wrap
            }

            .xxsmall-up-10>.column,
            .xxsmall-up-10>.columns {
                flex: 0 0 10%;
                max-width: 10%
            }

            .xxsmall-11 {
                flex: 0 0 68.75%;
                max-width: 68.75%
            }

            .xxsmall-offset-10 {
                margin-left: 62.5%
            }

            .xxsmall-order-11 {
                order: 11
            }

            .xxsmall-up-11 {
                flex-wrap: wrap
            }

            .xxsmall-up-11>.column,
            .xxsmall-up-11>.columns {
                flex: 0 0 9.0909090909%;
                max-width: 9.0909090909%
            }

            .xxsmall-12 {
                flex: 0 0 75%;
                max-width: 75%
            }

            .xxsmall-offset-11 {
                margin-left: 68.75%
            }

            .xxsmall-order-12 {
                order: 12
            }

            .xxsmall-up-12 {
                flex-wrap: wrap
            }

            .xxsmall-up-12>.column,
            .xxsmall-up-12>.columns {
                flex: 0 0 8.3333333333%;
                max-width: 8.3333333333%
            }

            .xxsmall-13 {
                flex: 0 0 81.25%;
                max-width: 81.25%
            }

            .xxsmall-offset-12 {
                margin-left: 75%
            }

            .xxsmall-order-13 {
                order: 13
            }

            .xxsmall-up-13 {
                flex-wrap: wrap
            }

            .xxsmall-up-13>.column,
            .xxsmall-up-13>.columns {
                flex: 0 0 7.6923076923%;
                max-width: 7.6923076923%
            }

            .xxsmall-14 {
                flex: 0 0 87.5%;
                max-width: 87.5%
            }

            .xxsmall-offset-13 {
                margin-left: 81.25%
            }

            .xxsmall-order-14 {
                order: 14
            }

            .xxsmall-up-14 {
                flex-wrap: wrap
            }

            .xxsmall-up-14>.column,
            .xxsmall-up-14>.columns {
                flex: 0 0 7.1428571429%;
                max-width: 7.1428571429%
            }

            .xxsmall-15 {
                flex: 0 0 93.75%;
                max-width: 93.75%
            }

            .xxsmall-offset-14 {
                margin-left: 87.5%
            }

            .xxsmall-order-15 {
                order: 15
            }

            .xxsmall-up-15 {
                flex-wrap: wrap
            }

            .xxsmall-up-15>.column,
            .xxsmall-up-15>.columns {
                flex: 0 0 6.6666666667%;
                max-width: 6.6666666667%
            }

            .xxsmall-16 {
                flex: 0 0 100%;
                max-width: 100%
            }

            .xxsmall-offset-15 {
                margin-left: 93.75%
            }

            .xxsmall-order-16 {
                order: 16
            }

            .xxsmall-up-16 {
                flex-wrap: wrap
            }

            .xxsmall-up-16>.column,
            .xxsmall-up-16>.columns {
                flex: 0 0 6.25%;
                max-width: 6.25%
            }
        }

        nav.temp[data-v-04d8e692] {
            display: flex;
            gap: 16px;
            left: 24px;
            position: fixed;
            top: 24px;
            z-index: 9
        }

        .-index[data-v-04d8e692] {
            font-size: 20px;
            position: relative;
            z-index: 1000
        }

        .page-transition[data-v-7aed90db] {
            height: 100%;
            left: 0;
            pointer-events: none;
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 999
        }

        .page-transition .inner[data-v-7aed90db] {
            background-color: #ff5f00;
            bottom: -50%;
            left: -50%;
            position: absolute;
            right: -50%;
            top: -50%
        }

        .loading[data-v-826c60ca] {
            cursor: wait;
            height: 200vh;
            top: -50vh;
            z-index: 999
        }

        .loading .curtain[data-v-826c60ca],
        .loading[data-v-826c60ca] {
            left: -50vw;
            position: fixed;
            width: 200vw
        }

        .loading .curtain[data-v-826c60ca] {
            background: #ff5f00;
            height: 100vh;
            overflow: hidden;
            top: 0;
            transform: rotate(0) translateY(0);
            transform: rotate(calc(15deg*var(--p, 0))) translateY(calc(-150%*var(--p, 0)))
        }

        .loading .curtain-inner[data-v-826c60ca] {
            align-items: center;
            bottom: 0;
            display: grid;
            justify-items: center;
            left: 0;
            place-items: center;
            position: absolute;
            right: 0;
            top: 0;
            transform: translateY(0) rotate(0);
            transform: translateY(calc(150%*var(--p, 0))) rotate(calc(-15deg*var(--p, 0)))
        }

        .loading .curtain-inner img[data-v-826c60ca] {
            display: none
        }

        @media only screen and (max-width:743px) {
            .loading .curtain-inner img[data-v-826c60ca] {
                animation: pulse-826c60ca 1.5s cubic-bezier(.645, .045, .355, 1) infinite;
                display: block
            }
        }

        @keyframes pulse-826c60ca {
            0% {
                opacity: .8;
                transform: scale(.95)
            }

            50% {
                opacity: 1;
                transform: scale(1)
            }

            to {
                opacity: .8;
                transform: scale(.95)
            }
        }

        .loading .curtain-inner svg[data-v-826c60ca] {
            fill: #fff
        }

        .video-modal-wrapper[data-v-15000e86] {
            --calculated-height: 100vh;
            --border-radius: 16px;
            --color: #fff;
            --background-color: #ff5f00;
            --transition-duration: 850ms;
            align-items: center;
            display: flex;
            height: 100%;
            height: 100vh;
            height: var(--calculated-height);
            justify-content: center;
            left: 0;
            overflow: hidden;
            pointer-events: none;
            position: absolute;
            top: 0;
            width: 100%;
            z-index: 6
        }

        .video-modal-wrapper.open[data-v-15000e86] {
            pointer-events: all;
            z-index: 30
        }

        .video-modal-wrapper.open[data-v-15000e86] .button {
            opacity: 1;
            pointer-events: all
        }

        .video-modal-wrapper.open .main-bg .inner[data-v-15000e86] {
            opacity: .95
        }

        .video-modal-wrapper.open .widget[data-v-15000e86] {
            opacity: 0;
            pointer-events: none
        }

        .video-modal-wrapper.open .video-wrapper[data-v-15000e86] {
            opacity: 1
        }

        .video-modal-wrapper.open .video-wrapper[data-v-15000e86] .plyr-container {
            pointer-events: all
        }

        .video-modal-wrapper .main-bg[data-v-15000e86] {
            height: 100%;
            left: 0;
            position: absolute;
            top: 0;
            width: 100%;
            z-index: 1
        }

        .video-modal-wrapper .main-bg .inner[data-v-15000e86] {
            background-color: #000;
            height: 100%;
            opacity: 0;
            width: 100%
        }

        .video-modal-wrapper[data-v-15000e86] .button {
            bottom: 82px;
            left: 50%;
            opacity: 0;
            pointer-events: none;
            position: absolute;
            transform: translateX(-50%);
            z-index: 2
        }

        .video-modal-wrapper .widget[data-v-15000e86] {
            background-color: hsla(0, 0%, 100%, .7);
            border-radius: 16px;
            cursor: pointer;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            max-width: 110px;
            min-height: 60px;
            min-width: 100px;
            padding: 4px;
            pointer-events: all;
            position: absolute;
            right: 12px;
            top: calc(var(--calculated-height) - 150px);
            z-index: 2
        }

        .video-modal-wrapper .widget [data-v-15000e86] {
            pointer-events: none
        }

        .video-modal-wrapper .widget .text-wrapper[data-v-15000e86] {
            display: flex;
            flex-direction: row;
            padding: 5px 0;
            position: relative;
            z-index: 2
        }

        .video-modal-wrapper .widget .text-wrapper .-body[data-v-15000e86] {
            color: #462617;
            font-size: 10px;
            letter-spacing: -.02em;
            line-height: 120%;
            padding-right: 10px
        }

        .video-modal-wrapper .widget .text-wrapper .play-button[data-v-15000e86] {
            color: #ff5f00;
            padding-left: 5px;
            padding-right: 5px
        }

        .video-modal-wrapper .widget .text-wrapper .play-button .icon[data-v-15000e86] {
            width: 20px
        }

        .video-modal-wrapper .widget .video-thumb[data-v-15000e86] {
            min-height: 60px;
            min-width: 100px
        }

        .video-modal-wrapper .widget .video-thumb img[data-v-15000e86] {
            border-radius: 12px;
            width: 100%
        }

        .video-modal-wrapper .video-wrapper[data-v-15000e86] {
            opacity: 0;
            pointer-events: none;
            position: relative;
            width: 100%;
            z-index: 3
        }

        .video-modal-wrapper .video-wrapper.open[data-v-15000e86] .plyr-container {
            pointer-events: all
        }

        .video-modal-wrapper .video-wrapper[data-v-15000e86] .plyr-container .plyr--full-ui input[type=range] {
            color: #ff5f00
        }

        .video-modal-wrapper .video-wrapper[data-v-15000e86] .plyr-container .plyr__controls__item,
        .video-modal-wrapper .video-wrapper[data-v-15000e86] .plyr-container .plyr__tooltip {
            font-family: vista-med
        }

        .video-modal-wrapper .video-wrapper[data-v-15000e86] .plyr-container .plyr__control--overlaid,
        .video-modal-wrapper .video-wrapper[data-v-15000e86] .plyr-container .plyr__control:hover,
        .video-modal-wrapper .video-wrapper[data-v-15000e86] .plyr-container .plyr__control[aria-expanded=true] {
            background-color: #ff5f00
        }

        .video-modal-wrapper .video-wrapper[data-v-15000e86] .plyr-container video {
            border-radius: 0 !important
        }

        .video-modal-wrapper .video-wrapper .inner[data-v-15000e86] {
            margin: 0;
            overflow: hidden;
            pointer-events: none;
            position: relative
        }

        .video-modal-wrapper .video-wrapper .block-bg-cover[data-v-15000e86] {
            opacity: 0;
            z-index: 4
        }

        .video-modal-wrapper .video-wrapper .block-bg-cover video[data-v-15000e86] {
            left: 50%;
            position: absolute;
            top: 50%;
            transform: translate(-50%, -50%)
        }

        .video-modal-wrapper .video-wrapper[data-v-15000e86] .plyr-container {
            position: relative;
            z-index: 1
        }

        .video-modal-wrapper .video-wrapper[data-v-15000e86] .plyr-container .controls {
            pointer-events: all
        }

        .button {
            --border-radius: 16px;
            --color: #fff;
            --background-color: #ff5f00;
            --outline-color: #ff5f00;
            --transition-duration: 750ms;
            --transition-delay: 0ms;
            color: #ff5f00;
            display: inline-block;
            position: relative
        }

        .button.btn-audio .button-type {
            padding: 16px 20px 16px 10px
        }

        .button.btn-audio .button-icon {
            height: auto;
            width: auto
        }

        .button.btn-audio .lottie-wrapper {
            display: flex
        }

        .button.btn-audio .lottie-wrapper svg path {
            fill: #fff;
            stroke: #fff
        }

        .button:focus-visible .button-type {
            outline: 2px solid rgba(255, 95, 0, .5)
        }

        .button .button-inner .background,
        .button .button-type,
        .button .button-type .button-label {
            transition: var(--transition-duration) cubic-bezier(.075, .82, .165, 1) var(--transition-delay)
        }

        .button .button-type .button-label {
            overflow: visible;
            white-space: nowrap
        }

        .button .button-type .button-icon .icon path {
            transition: var(--transition-duration) cubic-bezier(.075, .82, .165, 1) var(--transition-delay)
        }

        .button[data-disabled=true] {
            --background-color: rgba(255, 95, 0, .05);
            --outline-color: rgba(255, 95, 0, 0);
            cursor: not-allowed;
            pointer-events: none
        }

        .button[data-disabled=true] .button-label {
            color: rgba(255, 95, 0, .25)
        }

        @media(hover:hover) {
            .button:hover .background {
                transform: scale(1.03)
            }

            .button:hover.-primary {
                --background-color: #fa5500;
                --outline-color: rgba(255, 95, 0, 0)
            }

            .button:hover.-outline,
            .button:hover.-secondary {
                --fill-color: #fff;
                --background-color: #ff5f00;
                --outline-color: #ff5f00
            }

            .button:hover.-outline .button-label,
            .button:hover.-secondary .button-label {
                color: #fff
            }

            .button:hover.-outline .button-icon .icon,
            .button:hover.-secondary .button-icon .icon {
                --fill-color: #fff !important
            }

            .button:hover.-outline .button-icon.-lottie-arrow .lottie-wrapper svg path,
            .button:hover.-secondary .button-icon.-lottie-arrow .lottie-wrapper svg path {
                stroke: var(--fill-color)
            }

            .button:hover.-secondary.-inverted-true {
                --background-color: #fff;
                --outline-color: #fff
            }

            .button:hover.-secondary.-inverted-true .button-label {
                color: #ff5f00
            }

            .button:hover.-secondary.-inverted-true .button-icon .icon {
                --fill-color: #ff5f00
            }
        }

        .button:active {
            transition: background-color var(--transition-duration) cubic-bezier(.075, .82, .165, 1) var(--transition-delay)
        }

        .button:active.-outline,
        .button:active.-primary,
        .button:active.-secondary {
            --background-color: rgba(255, 95, 0, .85);
            --outline-color: rgba(255, 95, 0, 0)
        }

        .button.-primary.-inverted-true {
            --color: #ff5f00;
            --background-color: #fff
        }

        .button.-secondary .button-label {
            color: var(--color)
        }

        .button.-secondary .button-icon .icon {
            --fill-color: var(--color)
        }

        .button.-secondary.-inverted-true {
            --background-color: hsla(0, 0%, 100%, .15);
            --outline-color: hsla(0, 0%, 100%, 0)
        }

        .button.-secondary.-inverted-true .button-label {
            color: var(--color)
        }

        .button.-secondary.-inverted-true .button-icon .icon {
            --fill-color: #fff
        }

        .button.-outline {
            --color: #ff5f00;
            --background-color: transparent;
            --outline-color: rgba(255, 95, 0, .3)
        }

        .button-inner {
            position: relative
        }

        .button-inner .background {
            background-color: var(--background-color);
            border-radius: var(--border-radius);
            height: 100%;
            left: 0;
            position: absolute;
            top: 0;
            transform: scale(1);
            width: 100%
        }

        .button-type {
            align-items: center;
            border: 2px solid var(--outline-color);
            border-radius: var(--border-radius);
            color: var(--color);
            display: flex;
            gap: 10px;
            height: 48px;
            justify-content: center;
            overflow: hidden;
            padding: 12px 16px
        }

        @media only screen and (min-width:2000px) {
            .button-type {
                height: 48px
            }
        }

        .button-type.-large {
            height: max(48px, calc(45.621px + .61vw));
            padding: 16px 20px
        }

        .button-type.-large.-no-label {
            width: max(48px, calc(45.621px + .61vw))
        }

        .button-type.-no-label {
            align-items: center;
            justify-content: center;
            padding: 0;
            width: 48px
        }

        .button-type.-no-label .button-icon {
            display: contents
        }

        .button-type.-lottie-download .lottie-wrapper,
        .button-type.-lottie-mail .lottie-wrapper {
            transform: scale(1.4)
        }

        .button-type.-lottie-arrow .lottie-wrapper {
            transform: scale(1.6)
        }

        .button-type.-lottie-play .lottie-wrapper {
            height: max(20.4px, calc(20.4px + .21vw));
            width: max(20.4px, calc(20.4px + .21vw))
        }

        .button-type .lottie-wrapper svg {
            transform: none !important
        }

        .button-type .button-label {
            display: grid;
            font-size: max(12px, calc(10.206px + .46vw));
            grid-template-columns: 1fr;
            grid-template-rows: 1fr;
            letter-spacing: -.01em;
            overflow: visible;
            position: relative;
            white-space: nowrap
        }

        @media only screen and (min-width:2000px) {
            .button-type .button-label .-body {
                font-size: 18px
            }
        }

        .button-type .button-icon {
            align-items: center;
            border: 1px solid var(--icon-outline-color);
            border-radius: 6px;
            display: flex;
            height: max(20.4px, calc(20.4px + .21vw));
            justify-content: center;
            margin-right: -6px;
            position: relative;
            width: max(20.4px, calc(20.4px + .21vw))
        }

        @media only screen and (min-width:2000px) {
            .button-type .button-icon {
                height: 24px;
                width: 24px
            }
        }

        .button-type .button-icon .icon {
            --fill-color: var(--color) !important;
            --size: max(20.4px, calc(20.4px + 0.21vw));
            --stroke-color: var(--color)
        }

        .button-type .button-icon.-lottie-arrow .lottie-wrapper svg path {
            stroke: var(--color)
        }

        span[data-v-7a9ee508] {
            pointer-events: none
        }

        a[data-disabled=false][data-v-7a9ee508] {
            cursor: pointer
        }

        .icon[data-v-1e5a7f10] {
            --stroke-color: #fff;
            --fill-color: #fff;
            --size: 24px;
            display: grid;
            height: 24px;
            height: var(--size);
            position: relative;
            width: 24px;
            width: var(--size)
        }

        .icon.-s16[data-v-1e5a7f10] {
            --size: 16px
        }

        .icon.-bistre[data-v-1e5a7f10] {
            --fill-color: #462617
        }

        .icon.-black[data-v-1e5a7f10] {
            --fill-color: #000
        }

        .icon.-orange[data-v-1e5a7f10] {
            --fill-color: #ff5f00
        }

        .icon svg[data-v-1e5a7f10] {
            height: 100%;
            position: relative;
            width: 100%
        }

        .icon svg[data-v-1e5a7f10] path {
            fill: var(--fill-color)
        }

        .icon svg[data-v-1e5a7f10] rect {
            fill: var(--fill-color)
        }

        .inner[data-v-57ba5f91] {
            position: relative;
            width: 100%
        }

        .inner:hover [data-component=video-controls][data-v-57ba5f91] {
            opacity: 1
        }

        .inner button[data-v-57ba5f91] {
            --transition-duration: 750ms;
            --transition-delay: 0ms;
            --background-color: hsla(0, 0%, 100%, .3);
            --outline-color: hsla(0, 0%, 100%, 0);
            --color: #fff;
            -webkit-backdrop-filter: blur(3px);
            backdrop-filter: blur(3px);
            bottom: max(30px, calc(27.036px + .76vw));
            left: 50%;
            opacity: 0;
            position: absolute;
            transform: translateX(-50%);
            transition: .75s cubic-bezier(.075, .82, .165, 1) 0s;
            transition: var(--transition-duration) cubic-bezier(.075, .82, .165, 1) var(--transition-delay)
        }

        img[data-v-57ba5f91] {
            border-radius: 16px;
            position: relative
        }

        img[data-v-57ba5f91],
        video[data-v-57ba5f91] {
            overflow: hidden;
            width: 100%
        }

        video[data-v-57ba5f91] {
            border-radius: 10px;
            position: absolute;
            top: 0;
            will-change: transform
        }

        [data-component=video-controls] {
            --videoControls-color: #ff5f00;
            --videoControls-backgroundColor: #fff;
            --videoControls-accentColor: rgba(255, 95, 0, .2);
            --progress: 0%;
            align-items: center;
            bottom: max(30px, calc(27.036px + .76vw));
            display: flex;
            gap: 10px;
            left: 50%;
            opacity: 0;
            position: absolute;
            transform: translateX(-50%);
            transition: .3s ease
        }

        [data-component=video-controls]:not(.open) .audio-button:hover .background {
            transform: scale(1.1)
        }

        [data-component=video-controls] .background {
            background-color: var(--videoControls-backgroundColor);
            border-radius: 16px;
            height: 100%;
            left: 0;
            position: absolute;
            top: 0;
            transition: .3s ease;
            width: 100%;
            z-index: 1
        }

        [data-component=video-controls] .tracker {
            align-items: center;
            border-radius: 16px;
            color: var(--videoControls-color);
            display: flex;
            gap: 10px;
            height: 48px;
            overflow: hidden;
            padding-left: 12px;
            padding-right: 16px;
            position: relative;
            transition: .2s ease;
            width: 240px
        }

        [data-component=video-controls] .tracker.hidden {
            height: 24px;
            padding-left: 0;
            padding-right: 0;
            width: 0
        }

        [data-component=video-controls] .tracker * {
            z-index: 3
        }

        [data-component=video-controls] .tracker .lottie-wrapper-play {
            cursor: pointer;
            margin-bottom: -3px;
            width: 24px
        }

        [data-component=video-controls] .tracker .lottie-wrapper-play svg {
            transform: none !important
        }

        [data-component=video-controls] .tracker .lottie-wrapper-play svg path {
            fill: #ff5f00;
            stroke: #ff5f00
        }

        [data-component=video-controls] .tracker .progress-container {
            background-color: var(--videoControls-accentColor);
            border-radius: max(20.4px, calc(20.4px + .21vw));
            cursor: pointer;
            display: block;
            flex-grow: 1;
            height: 4px;
            position: relative
        }

        [data-component=video-controls] .tracker .progress-container .progress {
            background-color: var(--videoControls-color);
            border-radius: max(20.4px, calc(20.4px + .21vw));
            display: block;
            height: 100%;
            position: relative;
            width: var(--progress)
        }

        [data-component=video-controls] .tracker .current-time {
            color: #ff5f00;
            font-family: vista-med;
            padding: 0
        }

        [data-component=video-controls] .audio-button {
            align-items: center;
            border-radius: 16px;
            color: var(--videoControls-color);
            cursor: pointer;
            display: flex;
            height: 48px;
            justify-content: center;
            position: relative;
            width: 48px;
            z-index: 3
        }

        [data-component=video-controls] .audio-button * {
            z-index: 3
        }

        [data-component=video-controls] .audio-button .lottie-wrapper {
            display: flex;
            height: 28px
        }

        [data-component=video-controls] .audio-button .lottie-wrapper svg {
            pointer-events: none
        }

        [data-component=video-controls] .audio-button .lottie-wrapper svg path {
            fill: #ff5f00;
            stroke: #ff5f00
        }

        .page[data-v-556c3dc0] {
            max-width: 100%;
            min-height: 100vh;
            overflow: hidden;
            width: 100vw
        }

        .page *>div[data-v-556c3dc0] {
            border-bottom: 1px solid transparent;
            border-top: 1px solid transparent
        }

        .home-header[data-v-231d3226] {
            --calculated-height: 100vh;
            color: #462617;
            height: max(650px, min(75vh, 900px));
            justify-content: center;
            padding-top: 95px;
            position: relative;
            width: 100%
        }

        @media only screen and (max-width:500px) {
            .home-header[data-v-231d3226] {
                height: max(650px, min(var(--calculated-height), 800px))
            }
        }

        .home-header .title[data-v-231d3226] {
            font-size: max(56px, min(7vh, 60px))
        }

        .home-header .col[data-v-231d3226] {
            position: relative
        }

        .home-header .arrow-down[data-v-231d3226] {
            bottom: 8%;
            left: 50%;
            opacity: 1;
            position: absolute;
            transform: translateX(-50%);
            transition: opacity .3s ease
        }

        .home-header .arrow-down button[data-v-231d3226] {
            animation: float-231d3226 1s infinite alternate
        }

        @keyframes float-231d3226 {
            0% {
                transform: translateY(-25%)
            }

            to {
                transform: translateY(25%)
            }
        }

        .home-header-scene[data-v-14d1a11b] {
            --storefront-height: 250px;
            --brick-column-har-cols: 4;
            background-image: url(/imgs/home/header/texture-tile.jpg);
            background-position: 50%;
            background-repeat: repeat;
            bottom: 0;
            left: 0;
            overflow: hidden;
            position: absolute;
            right: 0;
            top: 0
        }

        .home-header-scene .full-scene[data-v-14d1a11b] {
            display: none
        }

        @media(min-height:823px)and (max-height:823px)and (min-width:412px)and (max-width:412px) {
            .home-header-scene.hidden .full-scene[data-v-14d1a11b] {
                display: block;
                width: 100%
            }

            .home-header-scene.hidden .bicycle[data-v-14d1a11b],
            .home-header-scene.hidden .brick-column[data-v-14d1a11b],
            .home-header-scene.hidden .cup[data-v-14d1a11b],
            .home-header-scene.hidden .fence[data-v-14d1a11b],
            .home-header-scene.hidden .overflow-fill[data-v-14d1a11b],
            .home-header-scene.hidden .pavement[data-v-14d1a11b],
            .home-header-scene.hidden .storefront[data-v-14d1a11b],
            .home-header-scene.hidden[data-v-14d1a11b] .leaves {
                display: none
            }
        }

        @media(max-aspect-ratio:1/1) {
            .home-header-scene[data-v-14d1a11b] {
                --storefront-height: 36vh
            }
        }

        @media only screen and (max-aspect-ratio:1/1)and (max-width:1023px) {
            .home-header-scene[data-v-14d1a11b] {
                --storefront-height: 310px
            }
        }

        @media only screen and (max-aspect-ratio:1/1)and (max-width:413px) {
            .home-header-scene[data-v-14d1a11b] {
                --storefront-height: 250px
            }
        }

        @media(min-aspect-ratio:1/1) {
            .home-header-scene[data-v-14d1a11b] {
                --storefront-height: 50%
            }
        }

        .home-header-scene .overflow-fill[data-v-14d1a11b] {
            background-color: #badbe2;
            display: none;
            height: 100%;
            position: absolute;
            top: 0;
            width: calc(2px + (100vw - var(--grid-padding)*2)/ var(--grid-num-cols)*var(--brick-column-har-cols))
        }

        @media only screen and (min-aspect-ratio:1/1)and (min-width:743px) {
            .home-header-scene .overflow-fill[data-v-14d1a11b] {
                display: inline-block
            }
        }

        .home-header-scene .overflow-fill img[data-v-14d1a11b] {
            bottom: calc(var(--storefront-height)*.08 + var(--storefront-height)*.16);
            margin-bottom: -2px;
            min-height: calc(var(--storefront-height)*1.8);
            -o-object-fit: cover;
            object-fit: cover;
            position: absolute
        }

        .home-header-scene .overflow-fill.left[data-v-14d1a11b] {
            left: 0
        }

        .home-header-scene .overflow-fill.left img[data-v-14d1a11b] {
            -o-object-position: right;
            object-position: right
        }

        .home-header-scene .overflow-fill.right[data-v-14d1a11b] {
            right: 0
        }

        .home-header-scene .overflow-fill.right img[data-v-14d1a11b] {
            -o-object-position: left;
            object-position: left
        }

        .home-header-scene .brick-column[data-v-14d1a11b] {
            bottom: calc(var(--storefront-height)*.08 + var(--storefront-height)*.16);
            height: 100%;
            margin-bottom: -2px;
            position: absolute;
            width: auto
        }

        .home-header-scene .brick-column.left[data-v-14d1a11b] {
            left: 0;
            transform: translateX(min(-12px, -100% + var(--grid-inset))) scaleX(-1)
        }

        .home-header-scene .brick-column.right[data-v-14d1a11b] {
            right: 0;
            transform: translateX(max(12px, 100% - var(--grid-inset)))
        }

        @media only screen and (min-aspect-ratio:1/1)and (min-width:743px) {
            .home-header-scene .brick-column.left[data-v-14d1a11b] {
                left: calc((100vw - var(--grid-padding)*2)/ var(--grid-num-cols)*var(--brick-column-har-cols));
                transform: scaleX(-1)
            }

            .home-header-scene .brick-column.right[data-v-14d1a11b] {
                right: calc((100vw - var(--grid-padding)*2)/ var(--grid-num-cols)*var(--brick-column-har-cols));
                transform: none
            }
        }

        .home-header-scene .storefront[data-v-14d1a11b] {
            bottom: calc(var(--storefront-height)*.08 + var(--storefront-height)*.16);
            height: var(--storefront-height);
            max-width: -moz-max-content;
            max-width: max-content
        }

        .home-header-scene .pavement[data-v-14d1a11b],
        .home-header-scene .storefront[data-v-14d1a11b] {
            left: 50%;
            position: absolute;
            transform: translateX(-50%);
            width: auto
        }

        .home-header-scene .pavement[data-v-14d1a11b] {
            bottom: calc(var(--storefront-height)*.08);
            height: calc(var(--storefront-height)*.16 + 1px)
        }

        .home-header-scene .bicycle[data-v-14d1a11b] {
            bottom: calc(var(--storefront-height)*.08 + var(--storefront-height)*.16);
            height: calc(var(--storefront-height)*.44);
            position: absolute;
            right: 0;
            transform: translate(65%, 4%);
            width: auto
        }

        @media only screen and (min-aspect-ratio:1/1)and (min-width:743px) {
            .home-header-scene .bicycle[data-v-14d1a11b] {
                right: calc((100vw - var(--grid-padding)*2)/ var(--grid-num-cols)*var(--brick-column-har-cols));
                transform: translate(50%, 4%)
            }
        }

        .home-header-scene .fence[data-v-14d1a11b] {
            background: url(/imgs/home/header/fence-repeater.webp);
            background-position: 100%;
            background-size: contain;
            bottom: 0;
            height: calc(var(--storefront-height)*.344 + var(--storefront-height)*.16);
            position: absolute;
            width: 100%
        }

        .home-header-scene .cup[data-v-14d1a11b] {
            bottom: calc(var(--storefront-height)*.344 + var(--storefront-height)*.16 - .2vh);
            height: calc(var(--storefront-height)*.16);
            left: 8vw;
            position: absolute
        }

        @media only screen and (min-aspect-ratio:1/1)and (min-width:413px) {
            .home-header-scene .cup[data-v-14d1a11b] {
                left: calc(8vw + (100vw - var(--grid-padding)*2)/ var(--grid-num-cols)*var(--brick-column-har-cols))
            }
        }

        .home-header-scene[data-v-14d1a11b] .leaves {
            bottom: 0;
            left: 0;
            pointer-events: none;
            position: absolute;
            right: 0;
            top: 0;
            z-index: 9
        }

        .home-header-scene[data-v-14d1a11b] .leaves>.leaf {
            bottom: 0;
            left: 0;
            position: absolute;
            right: 0;
            top: 0;
            will-change: transform
        }

        .home-header-scene[data-v-14d1a11b] .leaves>.leaf>span {
            background-position: 50%;
            background-repeat: no-repeat;
            background-size: contain;
            height: calc(var(--storefront-height)*.16);
            position: absolute;
            right: 0;
            top: 0;
            width: calc(var(--storefront-height)*.16)
        }

        .home-header-scene[data-v-14d1a11b] .leaves>.leaf:first-child>span {
            background-image: url(/imgs/home/header/leaf-1.png)
        }

        .home-header-scene[data-v-14d1a11b] .leaves>.leaf:nth-child(2)>span {
            background-image: url(/imgs/home/header/leaf-2.png)
        }

        .home-header-scene[data-v-14d1a11b] .leaves>.leaf:nth-child(3)>span {
            background-image: url(/imgs/home/header/leaf-3.png)
        }

        .home-header-scene[data-v-14d1a11b] .leaves>.leaf:nth-child(4)>span {
            background-image: url(/imgs/home/header/leaf-4.png)
        }

        .home-header-scene[data-v-14d1a11b] .leaves>.leaf:nth-child(5)>span {
            background-image: url(/imgs/home/header/leaf-5.png)
        }

        .home-header-scene[data-v-14d1a11b] .leaves>.leaf:nth-child(6)>span {
            background-image: url(/imgs/home/header/leaf-6.png)
        }

        .home-header-scene[data-v-14d1a11b] .leaves>.leaf:nth-child(7)>span {
            background-image: url(/imgs/home/header/leaf-7.png)
        }

        .home-header-scene[data-v-14d1a11b] .leaves>.leaf:nth-child(8)>span {
            background-image: url(/imgs/home/header/leaf-8.png)
        }

        .awwwards[data-v-2b4f0b38] {
            left: 0;
            pointer-events: all;
            position: absolute;
            top: 50%;
            transform: translateY(-50%)
        }

        @media only screen and (max-width:1023px) {
            .awwwards[data-v-2b4f0b38] {
                transform: translateY(-50%) scale(.8);
                transform-origin: left
            }
        }

        .-products[data-v-07f0e946] {
            background-color: #f6c97d;
            overflow: hidden;
            padding-top: max(100px, calc(68.722px + 8.02vw));
            position: relative;
            width: 100vw
        }

        @media only screen and (max-width:1290px) {
            .-products[data-v-07f0e946] {
                padding-top: max(10px, calc(-77.828px + 22.52vw))
            }
        }

        @media only screen and (max-width:1023px) {
            .-products[data-v-07f0e946] {
                padding-top: max(58.5px, calc(58.5px + 20.38vw))
            }
        }

        .-products .blured-img[data-v-07f0e946] {
            bottom: 20%;
            position: absolute;
            right: -20%;
            width: 400px
        }

        @media only screen and (max-width:1023px) {
            .-products .blured-img[data-v-07f0e946] {
                display: none
            }
        }

        @media only screen and (max-width:743px) {
            .-products .blured-img[data-v-07f0e946] {
                bottom: 18%;
                right: -80%;
                width: 289px
            }
        }

        .section-label[data-v-07f0e946] {
            color: #462617;
            left: max(35px, calc(30.515px + 1.15vw));
            opacity: .5;
            position: absolute;
            top: 50px
        }

        .section-label[data-v-07f0e946]:before {
            background-color: #462617;
            border-radius: 20px;
            content: "";
            height: 8px;
            left: -16px;
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            width: 8px
        }

        .text-wrapper[data-v-07f0e946] {
            margin-bottom: max(50px, calc(35.102px + 3.82vw));
            perspective: 1070px;
            text-align: center
        }

        @media only screen and (min-width:2000px) {
            .text-wrapper[data-v-07f0e946] {
                margin-bottom: 15vw
            }
        }

        @media only screen and (max-width:1023px) {
            .text-wrapper .inner[data-v-07f0e946] {
                opacity: 0
            }
        }

        .text-wrapper [data-v-07f0e946] {
            will-change: transform
        }

        .text-wrapper .upper-label[data-v-07f0e946] {
            align-items: center;
            border: 1px solid #006845;
            border-radius: 40px;
            color: #006845;
            display: inline-flex;
            flex-direction: row;
            gap: 8px;
            justify-content: center;
            margin-bottom: 15px;
            padding: 7px 12px;
            will-change: transform
        }

        .text-wrapper .upper-label span[data-v-07f0e946] {
            font-family: vista-med;
            font-size: 15px;
            letter-spacing: -.02em;
            line-height: 16px;
            text-transform: uppercase
        }

        .text-wrapper .upper-label[data-v-07f0e946] .icon svg path {
            fill: #006845
        }

        .text-wrapper .-h1[data-v-07f0e946] {
            color: #462617;
            margin-bottom: 30px;
            text-transform: uppercase
        }

        .text-wrapper .-h1 [data-v-07f0e946],
        .text-wrapper .-h7[data-v-07f0e946] {
            will-change: transform
        }

        .text-wrapper .-h7[data-v-07f0e946] {
            color: #462617
        }

        .products-wrapper[data-v-07f0e946] {
            display: flex;
            justify-content: center;
            position: relative
        }

        .products-wrapper svg[data-v-07f0e946] {
            opacity: 0;
            position: absolute;
            top: min(-15px, calc(99.621px - 29.39vw));
            width: 140%
        }

        @media only screen and (max-width:1023px) {
            .products-wrapper svg[data-v-07f0e946] {
                width: 180%
            }
        }

        @media only screen and (max-width:743px) {
            .products-wrapper svg[data-v-07f0e946] {
                top: -215px;
                width: 180%
            }
        }

        .products-wrapper img[data-v-07f0e946] {
            position: absolute;
            top: min(-5px, calc(8.416px - 3.44vw));
            width: max(190px, calc(157.24px + 8.4vw));
            z-index: 2
        }

        .products-wrapper img.certificate[data-v-07f0e946] {
            width: max(180px, calc(150.243px + 7.63vw))
        }

        .bucket-wrapper[data-v-07f0e946] {
            display: flex;
            height: 500px;
            justify-content: center;
            margin: 0 auto;
            position: relative;
            width: -moz-fit-content;
            width: fit-content;
            width: 500px;
            z-index: 3
        }

        @media only screen and (max-width:1023px) {
            .bucket-wrapper[data-v-07f0e946] {
                height: auto;
                margin-top: 100px;
                min-height: 290px;
                min-width: 350px;
                width: 100%
            }

            .bucket-wrapper img[data-v-07f0e946] {
                width: 100%
            }
        }

        @media only screen and (max-width:743px) {
            .bucket-wrapper[data-v-07f0e946] {
                margin-top: 225px
            }
        }

        .-franchising[data-v-00eb2f76] {
            background-color: #ff5f00;
            margin-top: min(-23px, calc(-23px - 1.59vw));
            padding: max(90px, calc(55.758px + 8.78vw)) 0;
            position: relative
        }

        @media only screen and (max-width:1290px) {
            .-franchising[data-v-00eb2f76] {
                padding-top: max(53px, calc(53px + 17.47vw))
            }
        }

        @media only screen and (max-width:1023px) {
            .-franchising[data-v-00eb2f76] {
                padding-top: max(36px, calc(36px + 8.47vw))
            }
        }

        @media only screen and (max-width:743px) {
            .-franchising[data-v-00eb2f76] {
                padding-top: max(27px, calc(27px + 3.71vw))
            }
        }

        .-franchising .background-color[data-v-00eb2f76] {
            background-color: #ff5f00;
            height: 150px;
            position: absolute;
            width: 100vw;
            z-index: 1
        }

        .-franchising .background-color [data-v-00eb2f76] {
            will-change: transform
        }

        .-franchising .background-color.top[data-v-00eb2f76] {
            left: 0;
            top: -75px;
            z-index: 20
        }

        .-franchising .background-color.bottom[data-v-00eb2f76] {
            bottom: -75px;
            left: 0
        }

        .align-center[data-v-00eb2f76] {
            display: flex;
            flex-direction: column;
            justify-content: center
        }

        .section-label[data-v-00eb2f76] {
            color: #462617;
            left: max(35px, calc(30.515px + 1.15vw));
            opacity: .5;
            position: absolute;
            top: 50px;
            z-index: 2
        }

        .section-label[data-v-00eb2f76]:before {
            background-color: #462617;
            border-radius: 20px;
            content: "";
            height: 8px;
            left: -16px;
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            width: 8px
        }

        .text-wrapper[data-v-00eb2f76] {
            position: relative;
            text-align: center;
            z-index: 20
        }

        .text-wrapper [data-v-00eb2f76] {
            will-change: transform
        }

        @media only screen and (max-width:1290px) {
            .text-wrapper[data-v-00eb2f76] {
                margin-bottom: max(26px, calc(26px + 3.18vw))
            }
        }

        @media only screen and (max-width:743px) {
            .text-wrapper[data-v-00eb2f76] {
                margin-bottom: 40px;
                text-align: left
            }
        }

        .text-wrapper .-h1[data-v-00eb2f76] {
            color: #462617;
            font-size: max(56px, calc(22.07px + 8.7vw));
            line-height: .55em;
            text-transform: uppercase;
            white-space: pre-line
        }

        .text-wrapper .-h1 [data-v-00eb2f76] {
            will-change: transform
        }

        .text-wrapper .-h1[data-v-00eb2f76] .line {
            perspective: 1070px
        }

        @media only screen and (max-width:1290px) {
            .text-wrapper .-h1[data-v-00eb2f76] {
                line-height: .85em
            }
        }

        @media only screen and (max-width:743px) {
            .text-wrapper .-h1[data-v-00eb2f76] {
                line-height: .95em
            }
        }

        .text-wrapper .stores-number[data-v-00eb2f76] {
            height: max(118px, calc(103.102px + 3.82vw));
            opacity: 0;
            position: absolute;
            right: 5%;
            top: 5%;
            width: max(118px, calc(103.102px + 3.82vw))
        }

        .text-wrapper .stores-number [data-v-00eb2f76] {
            will-change: transform
        }

        @media only screen and (max-width:1290px) {
            .text-wrapper .stores-number[data-v-00eb2f76] {
                right: -2%;
                top: -12%
            }
        }

        @media only screen and (max-width:1023px) {
            .text-wrapper .stores-number[data-v-00eb2f76] {
                height: 70px;
                right: -2%;
                top: 85%;
                width: 70px
            }
        }

        @media only screen and (max-width:743px) {
            .text-wrapper .stores-number[data-v-00eb2f76] {
                height: 70px;
                right: -5%;
                top: 30%;
                width: 70px
            }
        }

        .list-wrapper[data-v-00eb2f76] {
            display: flex;
            flex-direction: row;
            gap: 24px;
            justify-content: center;
            margin: max(50px, calc(33.62px + 4.2vw)) 0
        }

        .list-wrapper [data-v-00eb2f76] {
            will-change: transform
        }

        @media only screen and (max-width:743px) {
            .list-wrapper[data-v-00eb2f76] {
                flex-direction: column
            }
        }

        .list-wrapper .-body[data-v-00eb2f76] {
            opacity: .65
        }

        .item[data-v-00eb2f76] {
            display: flex;
            flex-direction: row;
            gap: 8px
        }

        .video-wrapper[data-v-00eb2f76] {
            display: flex;
            justify-content: center;
            margin-top: min(-5px, calc(23.275px - 7.25vw));
            perspective: 1070px;
            position: relative;
            z-index: 2
        }

        .video-wrapper [data-v-00eb2f76] {
            will-change: transform
        }

        @media only screen and (max-width:1023px) {
            .video-wrapper[data-v-00eb2f76] {
                min-height: 180px
            }
        }

        @media only screen and (max-width:743px) {
            .video-wrapper .inner[data-v-00eb2f76] {
                opacity: 0
            }
        }

        .buttons-wrapper[data-v-00eb2f76] {
            display: flex;
            gap: 12px;
            justify-content: center
        }

        .buttons-wrapper .btn-catalog[data-v-00eb2f76] {
            --background-color: hsla(0, 0%, 100%, .15);
            --outline-color: hsla(0, 0%, 100%, 0);
            --color: #fff;
            background-color: #ff5f00
        }

        .-business[data-v-35b6a005] {
            background-color: #f6c97d;
            overflow: hidden;
            padding: max(180px, calc(160.656px + 4.96vw)) 0 max(100px, calc(68.722px + 8.02vw));
            position: relative
        }

        @media only screen and (max-width:1290px) {
            .-business[data-v-35b6a005] {
                padding-bottom: 0;
                padding-top: max(78.5px, calc(78.5px + 30.97vw))
            }
        }

        @media only screen and (max-width:1023px) {
            .-business[data-v-35b6a005] {
                padding: max(180px, calc(160.656px + 4.96vw)) 0 max(100px, calc(68.722px + 8.02vw))
            }
        }

        .row[data-v-35b6a005] {
            position: relative;
            z-index: 2
        }

        .row .columns[data-v-35b6a005] {
            align-items: center;
            display: flex;
            position: relative
        }

        canvas[data-v-35b6a005] {
            height: 100%;
            pointer-events: none;
            position: absolute;
            width: 100%;
            z-index: 4
        }

        .title-wrapper[data-v-35b6a005] {
            margin-bottom: max(80px, calc(77.036px + .76vw));
            margin-top: max(1px, calc(-26.793px + 6.87vw));
            position: relative;
            text-align: center
        }

        .title-wrapper .-h1[data-v-35b6a005] {
            color: #462617;
            line-height: .55em;
            text-transform: uppercase
        }

        .title-wrapper .-h1[data-v-35b6a005] .line {
            perspective: 1070px
        }

        @media only screen and (max-width:1290px) {
            .title-wrapper .-h1[data-v-35b6a005] {
                line-height: .85em
            }
        }

        @media only screen and (max-width:743px) {
            .title-wrapper .-h1[data-v-35b6a005] {
                line-height: .95em
            }
        }

        .title-wrapper img[data-v-35b6a005] {
            left: -60%;
            position: absolute;
            top: -190%;
            width: max(200px, calc(22.55px + 45.5vw))
        }

        @media only screen and (max-width:743px) {
            .title-wrapper img[data-v-35b6a005] {
                left: -70%;
                top: -90%
            }
        }

        .-start-now[data-v-fc28b4d4] {
            background-color: #ff5f00;
            display: flex;
            height: 100vh;
            padding: 19vh 0 205px;
            position: relative
        }

        @media only screen and (max-width:1023px) {
            .-start-now[data-v-fc28b4d4] {
                overflow: hidden
            }
        }

        .align-center[data-v-fc28b4d4] {
            display: flex;
            flex-direction: column;
            justify-content: center
        }

        .title-wrapper[data-v-fc28b4d4] {
            position: relative;
            text-align: center
        }

        .title-wrapper .-h1[data-v-fc28b4d4] {
            color: #462617;
            line-height: 1em;
            text-transform: uppercase
        }

        .title-wrapper .-h1[data-v-fc28b4d4] .line {
            perspective: 1070px
        }

        @media only screen and (max-width:1023px) {
            .title-wrapper .-h1[data-v-fc28b4d4] {
                margin: max(22.5px, calc(22.5px + 1.32vw)) 0
            }
        }

        .title-wrapper .-h7[data-v-fc28b4d4] {
            color: #462617;
            padding: max(22px, calc(22px + 1.06vw)) 0
        }

        button[data-v-fc28b4d4] {
            z-index: 6
        }

        .image-top[data-v-fc28b4d4] {
            top: -25px
        }

        .image-bottom[data-v-fc28b4d4],
        .image-top[data-v-fc28b4d4] {
            display: none;
            position: absolute;
            transform: scale(1.2);
            width: 100%
        }

        .image-bottom[data-v-fc28b4d4] {
            bottom: -25px
        }

        @media only screen and (max-width:1023px) {

            .image-bottom[data-v-fc28b4d4],
            .image-top[data-v-fc28b4d4] {
                display: block
            }
        }

        .-support[data-v-1539f2d0] {
            height: 900vh;
            overflow: hidden;
            position: relative;
            width: 100vw
        }

        .-support .inner[data-v-1539f2d0] {
            align-items: center;
            background-color: #ea7d71;
            background: linear-gradient(180deg, #f6c97d, #e8726e 50%, #171c60);
            display: flex;
            height: calc(100vh + 1px);
            justify-content: center;
            position: absolute;
            top: 0;
            width: 100%
        }

        .-support .inner .placeholder[data-v-1539f2d0] {
            height: 350px;
            position: absolute;
            width: 350px
        }

        .-support .inner .placeholder.top[data-v-1539f2d0] {
            left: 350px;
            top: 0
        }

        .-support .inner .placeholder.center[data-v-1539f2d0] {
            bottom: 100px;
            left: 200px
        }

        .-support .inner .placeholder.bottom[data-v-1539f2d0] {
            bottom: -175px;
            right: 300px
        }

        .-support .inner .row[data-v-1539f2d0] {
            position: absolute
        }

        .-support .inner .row .col[data-v-1539f2d0] {
            perspective: 1700px
        }

        .-support .inner .row .col [data-v-1539f2d0] {
            will-change: transform
        }

        .-support .inner .row[data-v-1539f2d0]:first-child {
            opacity: 1;
            position: relative;
            top: 0
        }

        .-support .inner .media[data-v-1539f2d0] {
            height: 100%;
            left: 0;
            pointer-events: none;
            position: absolute;
            top: 0;
            width: 100%
        }

        .-support .inner .media img[data-v-1539f2d0] {
            will-change: transform
        }

        .-support .inner .media .point-one img[data-v-1539f2d0]:first-child {
            bottom: 0;
            left: 50%;
            position: absolute;
            transform: translateX(-50%);
            transform-origin: center bottom;
            width: max(61px, calc(61px + 21.71vw))
        }

        @media only screen and (max-width:1023px) {
            .-support .inner .media .point-one img[data-v-1539f2d0]:first-child {
                display: none
            }
        }

        .-support .inner .media .point-one img[data-v-1539f2d0]:nth-child(2) {
            left: 20%;
            position: absolute;
            top: 40%;
            width: max(29.9px, calc(29.9px + 5.24vw))
        }

        .-support .inner .media .point-one img[data-v-1539f2d0]:nth-child(3) {
            position: absolute;
            right: 25%;
            top: 25%;
            width: max(29.9px, calc(29.9px + 5.24vw))
        }

        .-support .inner .media .point-two img[data-v-1539f2d0] {
            border-radius: 16px;
            overflow: hidden
        }

        .-support .inner .media .point-two img[data-v-1539f2d0]:first-child {
            left: 10%;
            position: absolute;
            top: 20%;
            transform: rotate(-15deg);
            width: max(49.4px, calc(49.4px + 15.56vw))
        }

        .-support .inner .media .point-two img[data-v-1539f2d0]:nth-child(2) {
            position: absolute;
            right: 12%;
            top: 35%;
            transform: rotate(20deg);
            width: max(49.4px, calc(49.4px + 15.56vw))
        }

        .-support .inner .media .point-three img[data-v-1539f2d0]:first-child {
            left: 5%;
            position: absolute;
            top: 5%;
            transform: rotate(-15deg);
            width: max(53px, calc(53px + 17.47vw))
        }

        .-support .inner .media .point-three img[data-v-1539f2d0]:nth-child(2) {
            position: absolute;
            right: 60%;
            top: 70%;
            transform: rotate(5deg);
            width: max(38px, calc(38px + 9.53vw))
        }

        .-support .inner .media .point-three img[data-v-1539f2d0]:nth-child(3) {
            position: absolute;
            right: 12%;
            top: 10%;
            transform: rotate(20deg);
            width: max(49.4px, calc(49.4px + 15.56vw))
        }

        .-support .inner .media .point-four img[data-v-1539f2d0]:first-child {
            left: 5%;
            position: absolute;
            top: 5%;
            width: max(46.3px, calc(46.3px + 13.92vw))
        }

        .-support .inner .media .point-four img[data-v-1539f2d0]:nth-child(2) {
            position: absolute;
            right: 60%;
            top: 70%;
            width: max(46.3px, calc(46.3px + 13.92vw))
        }

        .-support .inner .media .point-four img[data-v-1539f2d0]:nth-child(3) {
            position: absolute;
            right: 12%;
            top: 25%;
            width: max(46.3px, calc(46.3px + 13.92vw))
        }

        .-support .inner .media .point-four img[data-v-1539f2d0]:nth-child(4) {
            position: absolute;
            right: 55%;
            top: 20%;
            width: max(36px, calc(36px + 8.47vw))
        }

        .-support .inner .media .point-four img[data-v-1539f2d0]:nth-child(5) {
            position: absolute;
            right: 35%;
            top: 15%;
            width: max(36px, calc(36px + 8.47vw))
        }

        .-support.mobile[data-v-1539f2d0] {
            height: 100vh;
            overflow: hidden;
            width: 100vw
        }

        .-support.mobile .inner .row .col[data-v-1539f2d0] {
            perspective: 1500px
        }

        .-support.mobile .inner .buttons[data-v-1539f2d0] {
            align-items: center;
            bottom: 30%;
            display: flex;
            gap: 10px;
            justify-content: center;
            left: 50%;
            position: absolute;
            transform: translateX(-50%);
            z-index: 6
        }

        .-support.mobile .inner .buttons button[data-v-1539f2d0] {
            align-items: center;
            background-color: hsla(0, 0%, 100%, .1);
            border-radius: 16px;
            cursor: pointer;
            display: flex;
            height: 48px;
            justify-content: center;
            width: 48px
        }

        .-support.mobile .inner .buttons button.disabled[data-v-1539f2d0] {
            background-color: hsla(0, 0%, 100%, .05);
            pointer-events: none
        }

        .-support.mobile .inner .buttons button.disabled .icon[data-v-1539f2d0] {
            opacity: .2
        }

        .-support.mobile .inner .media .point-one img[data-v-1539f2d0]:first-child {
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 230px
        }

        .-support.mobile .inner .media .point-one img[data-v-1539f2d0]:nth-child(2) {
            left: 5%;
            top: 52%;
            width: 60px
        }

        .-support.mobile .inner .media .point-one img[data-v-1539f2d0]:nth-child(3) {
            right: 3%;
            top: 40%;
            width: 60px
        }

        .-support.mobile .inner .media .point-two img[data-v-1539f2d0]:first-child {
            left: 10%;
            top: 15%;
            transform: rotate(-15deg);
            width: 200px
        }

        .-support.mobile .inner .media .point-two img[data-v-1539f2d0]:nth-child(2) {
            bottom: 9%;
            right: 12%;
            top: auto;
            transform: rotate(20deg);
            width: 150px
        }

        .-support.mobile .inner .media .point-three img[data-v-1539f2d0]:first-child {
            left: 5%;
            top: 5%;
            transform: rotate(-15deg);
            width: 190px
        }

        .-support.mobile .inner .media .point-three img[data-v-1539f2d0]:nth-child(2) {
            right: 50%;
            top: 80%;
            transform: rotate(5deg);
            width: 120px
        }

        .-support.mobile .inner .media .point-three img[data-v-1539f2d0]:nth-child(3) {
            right: -3%;
            top: 23%;
            transform: rotate(20deg);
            width: 130px
        }

        .-support.mobile .inner .media .point-four img[data-v-1539f2d0]:first-child {
            left: 5%;
            top: 5%;
            width: max(46.3px, calc(46.3px + 13.92vw))
        }

        .-support.mobile .inner .media .point-four img[data-v-1539f2d0]:nth-child(2) {
            right: 60%;
            top: 70%;
            width: max(46.3px, calc(46.3px + 13.92vw))
        }

        .-support.mobile .inner .media .point-four img[data-v-1539f2d0]:nth-child(3) {
            right: 12%;
            top: 25%;
            width: max(46.3px, calc(46.3px + 13.92vw))
        }

        .-support.mobile .inner .media .point-four img[data-v-1539f2d0]:nth-child(4) {
            right: 55%;
            top: 20%;
            width: max(36px, calc(36px + 8.47vw))
        }

        .-support.mobile .inner .media .point-four img[data-v-1539f2d0]:nth-child(5) {
            right: 35%;
            top: 15%;
            width: max(36px, calc(36px + 8.47vw))
        }

        .-caption[data-v-1539f2d0] {
            border: 1px solid hsla(0, 0%, 100%, .2);
            border-radius: 50px;
            font-family: vista-med;
            font-size: 16px;
            letter-spacing: -.06em;
            line-height: 90%;
            margin: 16px auto;
            padding: 9px 12px 7px;
            width: -moz-fit-content;
            width: fit-content
        }

        .-caption[data-v-1539f2d0],
        .-h4[data-v-1539f2d0] {
            color: #fff;
            opacity: 0;
            text-align: center;
            text-transform: uppercase;
            will-change: transform, opacity
        }

        .-h4[data-v-1539f2d0] {
            margin-bottom: max(20.4px, calc(20.4px + .21vw))
        }

        .-body[data-v-1539f2d0] {
            color: #fff;
            opacity: 0;
            text-align: center;
            white-space: pre-line;
            will-change: transform, opacity
        }

        .-footer[data-v-eac4d60a] {
            margin-top: -1px;
            position: relative;
            width: 100%
        }

        .-footer .mobile-scene[data-v-eac4d60a] {
            height: auto;
            position: relative;
            width: 100%
        }

        @media only screen and (max-width:743px) {
            .-footer .mobile-scene[data-v-eac4d60a] {
                height: 400px
            }
        }

        .-footer .mobile-scene img[data-v-eac4d60a] {
            height: auto;
            -o-object-fit: cover;
            object-fit: cover;
            -o-object-position: center bottom;
            object-position: center bottom;
            position: relative;
            width: 100%
        }

        @media only screen and (max-width:743px) {
            .-footer .mobile-scene img[data-v-eac4d60a] {
                height: 100%;
                position: absolute
            }
        }

        .-footer .row[data-v-eac4d60a] {
            bottom: 18px;
            padding: 0 max(20.4px, calc(20.4px + .21vw));
            position: absolute;
            width: 100%
        }

        @media only screen and (max-width:743px) {
            .-footer .row[data-v-eac4d60a] {
                bottom: auto;
                padding: 64px var(--grid-inset);
                position: relative
            }

            .-footer .row[data-v-eac4d60a]:after,
            .-footer .row[data-v-eac4d60a]:before {
                background-color: #91897d;
                bottom: 0;
                content: "";
                left: 0;
                position: absolute;
                right: 0;
                top: 0;
                z-index: 0
            }

            .-footer .row[data-v-eac4d60a]:after {
                background: linear-gradient(180deg, #91897d 10%, #090a11)
            }
        }

        .-footer .row .mobile-texture[data-v-eac4d60a] {
            height: 100%;
            left: 0;
            -o-object-fit: cover;
            object-fit: cover;
            -o-object-position: center top;
            object-position: center top;
            position: absolute;
            top: 0;
            width: 100%;
            z-index: 1
        }

        .-footer .row .col[data-v-eac4d60a] {
            align-items: center;
            display: flex;
            justify-content: space-between;
            padding: 0;
            position: relative;
            z-index: 1
        }

        @media only screen and (max-width:743px) {
            .-footer .row .col[data-v-eac4d60a] {
                flex-direction: column;
                gap: 16px
            }
        }

        .-footer .row .col .copyrights[data-v-eac4d60a] {
            align-items: center;
            display: flex;
            gap: max(4px, calc(2.206px + .46vw));
            width: -moz-fit-content;
            width: fit-content
        }

        @media only screen and (max-width:743px) {
            .-footer .row .col .copyrights[data-v-eac4d60a] {
                flex-direction: column;
                order: 2;
                width: 100%
            }

            .-footer .row .col .copyrights[data-v-eac4d60a]>:first-child {
                margin-top: 16px;
                order: 2
            }

            .-footer .row .col .copyrights[data-v-eac4d60a]>:nth-child(2) {
                order: 3
            }
        }

        .-footer .row .col .copyrights .text[data-v-eac4d60a] {
            color: hsla(0, 0%, 100%, .65);
            font-family: vista-reg;
            font-size: 16px;
            letter-spacing: -.04em
        }

        .-footer .row .col .copyrights a[data-v-eac4d60a] {
            position: relative
        }

        .-footer .row .col .copyrights a[data-v-eac4d60a]:after {
            background-color: #fff;
            bottom: -5px;
            content: "";
            height: 1px;
            left: 0;
            opacity: 0;
            position: absolute;
            transition: .2s ease;
            width: 100%
        }

        .-footer .row .col .copyrights a[data-v-eac4d60a]:hover:after {
            bottom: -1px;
            opacity: 1
        }

        .-footer .row .col .copyrights a p[data-v-eac4d60a],
        .-footer .row .col .copyrights span[data-v-eac4d60a] {
            color: #fff;
            font-family: vista-med;
            font-size: 16px;
            letter-spacing: -.04em
        }

        .-footer .row .col .copyrights .phone[data-v-eac4d60a] {
            display: flex;
            gap: 4px;
            margin-left: 4px
        }

        .-footer .row .col .copyrights .phone p[data-v-eac4d60a] {
            color: #fff;
            font-family: vista-reg;
            font-size: 16px;
            letter-spacing: -.04em
        }

        .-footer .row .col .copyrights .phone p[data-v-eac4d60a]:last-child {
            color: hsla(0, 0%, 100%, .65);
            font-size: 12px;
            margin-top: 3px
        }

        .-footer .row .col .social[data-v-eac4d60a] {
            display: flex;
            gap: 16px;
            justify-content: center;
            left: 50%;
            position: absolute;
            transform: translateX(-50%);
            width: -moz-fit-content;
            width: fit-content
        }

        @media only screen and (max-width:743px) {
            .-footer .row .col .social[data-v-eac4d60a] {
                left: auto;
                position: relative;
                transform: none
            }
        }

        .-footer .row .col .social ul[data-v-eac4d60a] {
            display: flex;
            gap: 16px;
            margin-top: 4px
        }

        @media only screen and (max-width:1023px) {
            .-footer .row .col .social ul[data-v-eac4d60a] {
                margin-top: -45px
            }
        }

        @media only screen and (max-width:743px) {
            .-footer .row .col .social ul[data-v-eac4d60a] {
                margin-top: 4px
            }
        }

        .-footer .row .col .social svg[data-v-eac4d60a] {
            overflow: visible
        }

        .-footer .row .col .social svg path[data-v-eac4d60a] {
            fill: #ff5f00;
            transition: .3s cubic-bezier(.19, 1, .22, 1)
        }

        .-footer .row .col .social svg path[data-v-eac4d60a]:first-child {
            fill: #fff;
            transform: scale(1);
            transform-origin: center
        }

        .-footer .row .col .social svg:hover path[data-v-eac4d60a] {
            fill: #fff
        }

        .-footer .row .col .social svg:hover path[data-v-eac4d60a]:first-child {
            fill: #ff5f00;
            transform: scale(1.2)
        }

        .-footer .row .col .madeby[data-v-eac4d60a] {
            display: flex;
            justify-content: flex-end;
            width: -moz-fit-content;
            width: fit-content
        }

        .-footer .row .col .madeby a[data-v-eac4d60a] {
            position: relative
        }

        .-footer .row .col .madeby a[data-v-eac4d60a]:after {
            background-color: #fff;
            bottom: -5px;
            content: "";
            height: 1px;
            left: 0;
            opacity: 0;
            position: absolute;
            transition: .2s ease;
            width: 100%
        }

        .-footer .row .col .madeby a[data-v-eac4d60a]:hover:after {
            bottom: -1px;
            opacity: 1
        }

        @media only screen and (max-width:743px) {
            .-footer .row .col .madeby[data-v-eac4d60a] {
                justify-content: center;
                margin-top: 16px;
                order: 3
            }
        }

        .-footer .row .col .madeby p[data-v-eac4d60a] {
            color: #fff;
            font-family: vista-med;
            font-size: 16px;
            letter-spacing: -.04em
        }

        span[data-v-21670aeb] {
            cursor: pointer
        }
    </style>
    <link rel="preload" href="/_nuxt/static/1727281647/state.js" as="script">
    <link rel="preload" href="/_nuxt/static/1727281647/payload.js" as="script">
    <link rel="preload" href="/_nuxt/static/1727281647/manifest.js" as="script">
</head>

<body>
    <div data-server-rendered="true" id="__nuxt">
        <div id="__layout">
            <div data-v-04d8e692>
                <div class="page-transition" data-v-7aed90db data-v-04d8e692>
                    <div class="inner" data-v-7aed90db></div>
                </div>
                <div class="loading" data-v-826c60ca data-v-04d8e692>
                    <div class="curtain" data-v-826c60ca>
                        <div class="curtain-inner" data-v-826c60ca><img src="/imgs/shared-header/storefront-awning-logo.svg" alt="Grab&Go logotype" data-v-826c60ca></div>
                    </div>
                </div> <!----> <!----> <span class="shade" data-v-04d8e692></span>
                <div class="video-modal-wrapper" data-v-15000e86 data-v-04d8e692><span class="main-bg" data-v-15000e86><span class="inner" data-v-15000e86></span> <button data-disabled="false" tabindex="0" aria-label="Close modal button" class="button -primary -inverted-false" data-v-7a9ee508 data-v-15000e86><span class="button-inner -noselect" data-v-7a9ee508><span class="background" data-v-7a9ee508></span> <span class="button-type -medium -primary -icon-close -lottie- -no-label" data-v-7a9ee508><!----> <!----> <!----> <!----> <span class="button-icon" data-v-7a9ee508>
                                        <div class="icon -close -s24 -bistre" data-v-1e5a7f10><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-1e5a7f10 data-v-1e5a7f10>
                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M19.0711 6.34314L6.34317 19.0711L4.92896 17.6569L17.6569 4.92893L19.0711 6.34314Z" fill="#462617" data-v-1e5a7f10 data-v-1e5a7f10></path>
                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M17.6568 19.0711L4.92893 6.34315L6.34314 4.92893L19.0711 17.6569L17.6568 19.0711Z" fill="#462617" data-v-1e5a7f10 data-v-1e5a7f10></path>
                                            </svg></div>
                                    </span></span></span></button></span>
                    <div class="widget" data-v-15000e86>
                        <div class="video-thumb" data-v-15000e86><img src="/_nuxt/image/91e3f3.auto" width="100" height="61" alt="Thumbnail video image" sizes="(max-width: 1023px) 40vw, 100vw" srcset="/_nuxt/image/8c16f3.auto 409w, /_nuxt/image/91e3f3.auto 1700w" data-v-15000e86></div>
                        <div class="text-wrapper" data-v-15000e86><span class="play-button" data-v-15000e86>
                                <div class="icon -play -s24 -orange" data-v-1e5a7f10 data-v-15000e86><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-1e5a7f10 data-v-1e5a7f10>
                                        <path d="M6.49805 4.83167C6.49805 4.0405 7.37329 3.56266 8.0388 3.99049L19.1895 11.1588C19.8019 11.5525 19.8019 12.4475 19.1895 12.8412L8.0388 20.0095C7.37329 20.4373 6.49805 19.9595 6.49805 19.1683V4.83167Z" fill="#462617" data-v-1e5a7f10 data-v-1e5a7f10></path>
                                    </svg></div>
                            </span>
                            <p class="-body" data-v-15000e86>Estamos Abertos 24h/dia</p>
                        </div>
                    </div>
                    <div class="video-wrapper" data-v-15000e86>
                        <div class="inner" data-v-15000e86>
                            <div class="block-bg-cover" data-v-15000e86><video src="/videos/header-teaser.mp4" class="element-cover" data-v-15000e86></video></div>
                            <div class="plyr-container" data-v-15000e86>
                                <div class="inner video-wrapper" data-v-57ba5f91 data-v-15000e86><img src="/_nuxt/image/3a31fc.webp" alt="video poster image" sizes="(max-width: 1023px) 50vw, 87vw" srcset="/_nuxt/image/2cb112.webp 512w, /_nuxt/image/3a31fc.webp 1479w" class="poster" data-v-57ba5f91> <video data-video-animation loop playsinline muted data-v-57ba5f91></video>
                                    <div data-component="video-controls" class="controls" style="--progress:0%" data-v-57ba5f91><span class="tracker hidden"><span class="background"></span>
                                            <div class="lottie-wrapper-play"></div> <span data-hitarea="1" class="progress-container"><span class="progress"></span></span> <time class="-body current-time">00:00</time>
                                        </span> <span class="audio-button"><span class="background"></span>
                                            <div class="lottie-wrapper"></div>
                                        </span></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> <!----> <!----> <!---->
                <div class="page" data-v-556c3dc0 data-v-04d8e692>
                    <div data-v-7ab4eea4><!---->
                        <header data-bgl-scroll-from="cup-header" modalvideo="[object Object]" class="home-header row" data-v-231d3226 data-v-7ab4eea4>
                            <figure class="home-header-scene hidden" data-v-14d1a11b data-v-231d3226><img src="/_nuxt/image/8faf16.auto" alt="Full scene" loading="lazy" sizes="(max-width: 743px) 100vw, 17vw" srcset="/_nuxt/image/f40044.auto 743w, /_nuxt/image/8faf16.auto 289w" class="full-scene" data-v-14d1a11b> <span class="overflow-fill left" data-v-14d1a11b><img src="/_nuxt/image/504750.auto" alt="Street scene" loading="lazy" sizes="(max-width: 743px) 100vw, 17vw" srcset="/_nuxt/image/3f0c24.auto 743w, /_nuxt/image/504750.auto 289w" data-v-14d1a11b></span> <span class="overflow-fill right" data-v-14d1a11b><img src="/_nuxt/image/66d06a.auto" alt="Street scene" loading="lazy" sizes="(max-width: 743px) 100vw, 17vw" srcset="/_nuxt/image/849f4e.auto 743w, /_nuxt/image/66d06a.auto 289w" data-v-14d1a11b></span> <img src="/_nuxt/image/048a4b.auto" alt="Brick column" loading="lazy" sizes="(max-width: 743px) 100vw, 17vw" srcset="/_nuxt/image/474752.auto 743w, /_nuxt/image/048a4b.auto 289w" class="brick-column left" data-v-14d1a11b> <img src="/_nuxt/image/048a4b.auto" alt="Brick column" loading="lazy" sizes="(max-width: 743px) 100vw, 17vw" srcset="/_nuxt/image/474752.auto 743w, /_nuxt/image/048a4b.auto 289w" class="brick-column right" data-v-14d1a11b> <img src="/_nuxt/image/5af623.auto" width="1222" height="802" alt="Grab&Go store" loading="lazy" sizes="(max-width: 743px) 100vw, 17vw" srcset="/_nuxt/image/82e9e4.auto 743w, /_nuxt/image/5af623.auto 289w" class="storefront" data-v-14d1a11b> <img src="/_nuxt/image/2c680c.auto" alt="Pavement" loading="lazy" sizes="(max-width: 743px) 100vw, 17vw" srcset="/_nuxt/image/e787cc.auto 743w, /_nuxt/image/2c680c.auto 289w" class="pavement" data-v-14d1a11b> <img src="/_nuxt/image/94f0b8.auto" alt="Bicycle" loading="lazy" sizes="(max-width: 743px) 100vw, 17vw" srcset="/_nuxt/image/b3834a.auto 743w, /_nuxt/image/94f0b8.auto 289w" class="bicycle" data-v-14d1a11b> <span class="fence" data-v-14d1a11b></span> <img src="/_nuxt/image/6a9d70.auto" alt="Printed paper cup" loading="lazy" sizes="(max-width: 410px) 100vw, 17vw" srcset="/_nuxt/image/66bdcf.auto 410w, /_nuxt/image/6a9d70.auto 289w" data-bgl-track="cup-header-from" data-bgl-placeholder="" class="cup" data-v-14d1a11b> <span class="leaves" data-v-14d1a11b></span></figure>
                            <div class="col xxlarge-6 medium-8 small-10 xsmall-16" data-v-231d3226>
                                <h1 class="title -h1 -text-center -uppercase" data-v-231d3226>Você descansa o seu negócio não</h1>
                            </div> <span class="arrow-down scroll-down-button" data-v-231d3226><button data-disabled="false" tabindex="0" aria-label="scroll down button" class="button -primary -inverted-false" data-v-7a9ee508 data-v-231d3226><span class="button-inner -noselect" data-v-7a9ee508><span class="background" data-v-7a9ee508></span> <span class="button-type -large -primary -icon-arrow-down -lottie- -no-label" data-v-7a9ee508><!----> <span class="button-icon" data-v-7a9ee508>
                                                <div class="icon -arrow-down -s24 -bistre" data-v-1e5a7f10><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-1e5a7f10 data-v-1e5a7f10>
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M13 19L11.9929 20.0071L5.28578 13.3L6.7 11.8858L11 16.1858L11 4H13L13 16.1716L17.2858 11.8858L18.7 13.3L13 19Z" fill="#462617" data-v-1e5a7f10 data-v-1e5a7f10></path>
                                                    </svg></div>
                                            </span> <!----> <!----> <!----></span></span></button></span>
                            <div class="awwwards" data-v-2b4f0b38 data-v-231d3226><a href="https://www.awwwards.com/sites/grab-go" target="_blank" arial-label="Link to the awwwards website." data-v-2b4f0b38><svg width="53.08" height="171.358" class="desktop" data-v-2b4f0b38>
                                        <path fill="#ffffff" d="M0 0h53.08v171.358H0z" data-v-2b4f0b38></path>
                                        <g fill="#000000" data-v-2b4f0b38>
                                            <path d="M30.016 151.575a3.599 3.599 0 0 1-2.484 1.878l-.965-1.535c.623-.155 1.126-.401 1.506-.737.38-.337.57-.768.57-1.293 0-.4-.101-.722-.301-.966-.199-.242-.504-.365-.912-.365-.254 0-.478.083-.674.249a2.423 2.423 0 0 0-.511.62c-.146.249-.331.603-.556 1.061l-.204.424c-.293.584-.66 1.052-1.104 1.403-.443.351-1.011.525-1.703.525-.516 0-.983-.119-1.402-.357-.42-.239-.748-.575-.986-1.009s-.357-.929-.357-1.483c0-1.413.619-2.378 1.855-2.895l.979 1.535c-.721.253-1.082.706-1.082 1.359 0 .282.09.526.271.73.182.205.402.308.665.308s.495-.091.694-.271a2.51 2.51 0 0 0 .512-.657c.141-.258.324-.631.548-1.118.224-.478.454-.879.687-1.206a2.76 2.76 0 0 1 .914-.803c.375-.211.83-.315 1.367-.315.613 0 1.152.139 1.614.417.463.278.819.665 1.067 1.162s.373 1.062.373 1.695a3.545 3.545 0 0 1-.381 1.644M21.627 145.02a1.13 1.13 0 0 1-.833.336c-.332 0-.61-.111-.834-.336s-.336-.502-.336-.833c0-.332.112-.608.336-.833s.502-.337.834-.337c.331 0 .608.112.833.337s.336.501.336.833c0 .331-.111.608-.336.833m1.285-1.74h7.367v1.812h-7.367v-1.812zM29.709 140.226c-.458.479-1.135.716-2.031.716h-3.216v1.141h-1.55v-1.141H21.07l-1.139-1.812h2.98v-1.945h1.55v1.945h3.187c.438 0 .748-.081.928-.242.181-.16.27-.402.27-.723 0-.244-.057-.479-.175-.702l1.462-.424c.176.38.264.779.264 1.198-.001.849-.23 1.511-.688 1.989M29.833 134.72a3.333 3.333 0 0 1-1.433 1.169c-.579.249-1.182.373-1.805.373s-1.225-.124-1.805-.373a3.347 3.347 0 0 1-1.434-1.169c-.375-.531-.563-1.196-.563-1.995 0-.77.184-1.413.549-1.93a3.282 3.282 0 0 1 1.381-1.14 4.239 4.239 0 0 1 1.711-.365h.746v5.072a1.796 1.796 0 0 0 1.168-.49c.332-.307.496-.724.496-1.249 0-.41-.092-.753-.277-1.031-.185-.277-.473-.528-.862-.753l.542-1.462c.691.303 1.223.724 1.592 1.265.371.541.557 1.235.557 2.083 0 .798-.188 1.463-.563 1.995m-4.085-3.574c-.41.088-.746.261-1.009.519s-.394.611-.394 1.06c0 .429.135.784.408 1.067s.604.458.994.526v-3.172zM29.898 122.64c-.33.565-.783.996-1.359 1.294-.574.297-1.221.445-1.943.445-.721 0-1.369-.148-1.943-.445-.576-.298-1.029-.729-1.36-1.294s-.496-1.232-.496-2.002c0-.771.165-1.438.496-2.003a3.301 3.301 0 0 1 1.36-1.293c.574-.298 1.223-.446 1.943-.446.723 0 1.369.148 1.943.446a3.293 3.293 0 0 1 1.359 1.293c.332.564.497 1.232.497 2.003.001.769-.165 1.436-.497 2.002m-1.703-3.347c-.433-.331-.967-.497-1.6-.497s-1.167.166-1.602.497c-.433.33-.649.778-.649 1.345 0 .564.217 1.013.649 1.344.435.332.969.498 1.602.498s1.167-.166 1.6-.498c.435-.331.65-.779.65-1.344.001-.567-.215-1.015-.65-1.345M24.462 115.16v.936h-1.55v-.936h-.381c-.866 0-1.516-.227-1.95-.68-.433-.453-.649-1.074-.649-1.863 0-.556.096-1.014.291-1.374l1.463.396a2.238 2.238 0 0 0-.205.876c0 .556.307.834.92.834h.512v-1.55h1.55v1.55h5.817v1.812h-5.818zM29.709 105.543c-.458.479-1.135.717-2.031.717h-3.216v1.14h-1.55v-1.14H21.07l-1.139-1.813h2.98v-1.944h1.55v1.944h3.187c.438 0 .748-.081.928-.241.181-.16.27-.402.27-.724 0-.244-.057-.478-.175-.702l1.462-.424c.176.38.264.78.264 1.199-.001.848-.23 1.51-.688 1.988M19.931 101.104v-1.812h4.166a2.805 2.805 0 0 1-.942-.973 2.622 2.622 0 0 1-.358-1.367c0-.711.188-1.271.562-1.681.376-.409.93-.614 1.66-.614h5.262v1.813H25.66c-.449 0-.779.09-.994.27-.215.181-.321.455-.321.826 0 .292.103.57.308.833.204.263.516.478.936.644.418.166.945.249 1.578.249h3.113v1.812H19.931zM29.833 91.469a3.333 3.333 0 0 1-1.433 1.169 4.545 4.545 0 0 1-3.61 0 3.345 3.345 0 0 1-1.433-1.169c-.375-.532-.563-1.197-.563-1.995 0-.771.184-1.413.549-1.93a3.284 3.284 0 0 1 1.381-1.141 4.239 4.239 0 0 1 1.711-.365h.746v5.072c.446-.02.838-.183 1.168-.49.332-.307.496-.724.496-1.249 0-.409-.092-.753-.277-1.03-.185-.278-.473-.529-.862-.753l.542-1.462c.691.302 1.223.724 1.592 1.265.371.541.557 1.234.557 2.083-.001.797-.189 1.463-.564 1.995m-4.085-3.574c-.41.088-.746.261-1.009.519-.263.259-.394.611-.394 1.061 0 .428.135.784.408 1.066s.604.458.994.526v-3.172zM20.047 80.572V77.37c0-.847.187-1.631.557-2.353.369-.721.938-1.303 1.703-1.746.764-.444 1.717-.665 2.857-.665 1.139 0 2.092.221 2.857.665.764.443 1.332 1.025 1.701 1.746.371.722.557 1.506.557 2.353v3.202H20.047zm8.478-2.601c0-.975-.251-1.791-.753-2.448-.501-.658-1.372-.987-2.608-.987-1.238 0-2.107.329-2.609.987-.502.657-.754 1.474-.754 2.448v.701h6.725v-.701zM29.812 70.685c-.39.419-.94.628-1.651.628-.731 0-1.315-.277-1.754-.833s-.658-1.306-.658-2.251v-1.286h-.321c-.36 0-.631.122-.812.365s-.271.551-.271.921c0 .633.282 1.059.849 1.271l-.352 1.535a2.326 2.326 0 0 1-1.484-.943c-.374-.512-.562-1.133-.562-1.863 0-.984.261-1.747.782-2.288.521-.54 1.289-.812 2.302-.812h4.399v1.492l-.936.19c.702.573 1.052 1.33 1.052 2.265.001.653-.194 1.19-.583 1.609m-1.382-3.246c-.277-.332-.645-.497-1.104-.497h-.146v1.213c0 .4.078.709.233.929.156.219.395.328.717.328a.655.655 0 0 0 .519-.227c.132-.151.197-.348.197-.592a1.742 1.742 0 0 0-.416-1.154M29.812 61.639l-6.9 2.674v-1.827l4.619-1.711-4.619-1.607v-1.813l10.349 3.801v1.754zM35.481 17.006l-4.782 14.969h-3.266l-2.584-9.682-2.584 9.682h-3.267l-4.783-14.969h3.713l2.674 10.275 2.525-10.275h3.444l2.525 10.275 2.674-10.275zM37.979 27.163c1.426 0 2.496 1.069 2.496 2.495 0 1.425-1.07 2.495-2.496 2.495s-2.494-1.07-2.494-2.495c-.001-1.426 1.068-2.495 2.494-2.495" data-v-2b4f0b38></path>
                                        </g>
                                    </svg></a></div>
                        </header>
                        <section data-bgl-track="header-to" class="-products bg-texture" data-v-07f0e946 data-v-7ab4eea4>
                            <div class="row" data-v-07f0e946>
                                <div class="xxlarge-16 columns" data-v-07f0e946>
                                    <div data-parent class="text-wrapper" data-v-07f0e946>
                                        <div class="inner" data-v-07f0e946>
                                            <div data-animation data-offset="0.4" class="upper-label" data-v-07f0e946><span data-v-07f0e946>
                                                    <div class="icon -verified-products -s24 -bistre" data-v-1e5a7f10 data-v-07f0e946><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-1e5a7f10 data-v-1e5a7f10>
                                                            <path d="M23 12.46L20.58 9.67L20.9 5.99L17.3 5.16L15.4 2L12 3.44L8.6 2L6.7 5.16L3.1 5.99L3.42 9.67L1 12.46L3.42 15.25L3.1 18.93L6.7 19.76L8.6 22.92L12 21.48L15.4 22.92L17.3 19.76L20.9 18.93L20.58 15.25L23 12.46ZM10.75 16.87L7.04 13.16L8.45 11.75L10.74 14.04L16.53 8.25L17.94 9.66L10.73 16.87H10.75Z" fill="#462617" data-v-1e5a7f10 data-v-1e5a7f10></path>
                                                        </svg></div>
                                                </span> <span data-v-07f0e946>Controlo diário</span></div>
                                            <h2 data-animation class="-h1" data-v-07f0e946>Entra, pega, leva</h2>
                                            <p data-animation data-offset="0.6" class="-h7" data-v-07f0e946>+400 produtos disponíveis 24h / 365 dias</p>
                                        </div>
                                    </div>
                                    <div class="products-wrapper" data-v-07f0e946><!----> <!----> <img src="/_nuxt/image/336a7e.auto" alt="Product Image" sizes="(max-width: 1023px) 20vw, 100vw" srcset="/_nuxt/image/935b92.auto 205w, /_nuxt/image/336a7e.auto 1700w" data-v-07f0e946><img src="/_nuxt/image/933e5e.auto" alt="Product Image" sizes="(max-width: 1023px) 20vw, 100vw" srcset="/_nuxt/image/f60d31.auto 205w, /_nuxt/image/933e5e.auto 1700w" data-v-07f0e946><img src="/_nuxt/image/3c0f4e.auto" alt="Product Image" sizes="(max-width: 1023px) 20vw, 100vw" srcset="/_nuxt/image/09c598.auto 205w, /_nuxt/image/3c0f4e.auto 1700w" data-v-07f0e946><img src="/_nuxt/image/2dcb2e.auto" alt="Product Image" sizes="(max-width: 1023px) 20vw, 100vw" srcset="/_nuxt/image/e906fa.auto 205w, /_nuxt/image/2dcb2e.auto 1700w" data-v-07f0e946><img src="/_nuxt/image/1d73e2.auto" alt="Product Image" sizes="(max-width: 1023px) 20vw, 100vw" srcset="/_nuxt/image/605323.auto 205w, /_nuxt/image/1d73e2.auto 1700w" data-v-07f0e946> <!----></div>
                                    <div data-bgl-track="cup-header-to" data-bgl-placeholder class="bucket-wrapper" data-v-07f0e946><img src="/_nuxt/image/8063c2.auto" width="500" height="500" alt="Bucket placeholder Image" sizes="(max-width: 1023px) 40vw, 100vw" srcset="/_nuxt/image/95c45e.auto 409w, /_nuxt/image/8063c2.auto 1700w" data-v-07f0e946></div>
                                </div>
                            </div> <img src="/_nuxt/image/7984b4.auto" alt="Potato Chip blured image" loading="lazy" sizes="(max-width: 743px) 20vw, (max-width: 1023px) 30vw, 87vw" srcset="/_nuxt/image/6a78f8.auto 149w, /_nuxt/image/6c52e3.auto 307w, /_nuxt/image/7984b4.auto 1479w" class="blured-img" data-v-07f0e946>
                        </section>
                        <section class="-franchising bg-texture-orange" data-v-00eb2f76 data-v-7ab4eea4><span class="background-color top bg-texture-orange" data-v-00eb2f76></span> <span class="background-color bottom bg-texture-orange" data-v-00eb2f76></span>
                            <div class="row" data-v-00eb2f76>
                                <div class="xxlarge-16 columns" data-v-00eb2f76>
                                    <div class="text-wrapper" data-v-00eb2f76>
                                        <h2 data-animation data-split class="-h1" data-v-00eb2f76>O MAIOR
                                            FRANCHISING
                                            EUROPEU DE LOJAS
                                            AUTOMÁTICAS</h2> <svg viewBox="0 0 168 168" fill="none" xmlns="http://www.w3.org/2000/svg" class="stores-number" data-v-00eb2f76>
                                            <g data-v-00eb2f76>
                                                <path d="M84 -3.67176e-06C130.392 -1.6439e-06 168 37.6081 168 84C168 130.392 130.392 168 84 168L-7.34351e-06 168L-3.67176e-06 84C-1.6439e-06 37.6081 37.6081 -5.69961e-06 84 -3.67176e-06Z" fill="white" data-v-00eb2f76></path>
                                                <circle cx="84" cy="84" r="48" fill="#FF5F00" data-v-00eb2f76></circle> <text fill="white" xml:space="preserve" font-family="vista-black" font-size="32" text-anchor="middle" letter-spacing="-0.04em" style="white-space:pre" data-v-00eb2f76>
                                                    <tspan x="84" y="87.08" data-v-00eb2f76>0</tspan>
                                                </text> <text fill="white" xml:space="preserve" font-family="vista-black" font-size="16" letter-spacing="-0.05em" style="white-space:pre" data-v-00eb2f76>
                                                    <tspan x="64.4434" y="104.08" data-v-00eb2f76>Lojas</tspan> <!---->
                                                </text>
                                            </g>
                                        </svg>
                                    </div>
                                    <div class="video-wrapper" data-v-00eb2f76>
                                        <div class="inner" data-v-57ba5f91 data-v-00eb2f76><img src="/_nuxt/image/5785e3.webp" alt="video poster image" sizes="(max-width: 1023px) 50vw, 87vw" srcset="/_nuxt/image/6657c8.webp 512w, /_nuxt/image/5785e3.webp 1479w" class="poster" data-v-57ba5f91> <video data-video-animation loop playsinline muted data-v-57ba5f91></video>
                                            <div data-component="video-controls" class="controls" style="--progress:0%" data-v-57ba5f91><span class="tracker hidden"><span class="background"></span>
                                                    <div class="lottie-wrapper-play"></div> <span data-hitarea="1" class="progress-container"><span class="progress"></span></span> <time class="-body current-time">00:00</time>
                                                </span> <span class="audio-button"><span class="background"></span>
                                                    <div class="lottie-wrapper"></div>
                                                </span></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row" data-v-00eb2f76>
                                <div class="xxlarge-12 xxlarge-offset-2 small-16 small-offset-0 xsmall-14 xsmall-offset-1 columns align-center" data-v-00eb2f76>
                                    <div class="list-wrapper" data-v-00eb2f76>
                                        <div class="item" data-v-00eb2f76><span data-v-00eb2f76>
                                                <div class="icon -briefcase -s24 -bistre" data-v-1e5a7f10 data-v-00eb2f76><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-1e5a7f10 data-v-1e5a7f10>
                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M20 7H16V6C16 4.34 14.66 3 13 3H11C9.34 3 8 4.34 8 6V7H4C2.9 7 2 7.9 2 9V20C2 21.1 2.9 22 4 22H20C21.1 22 22 21.1 22 20V9C22 7.9 21.1 7 20 7ZM10 6C10 5.45 10.45 5 11 5H13C13.55 5 14 5.45 14 6V7H10V6ZM12 18L8.5 14H10.5V11H13.5V14H15.5L12 18Z" fill="#462617" data-v-1e5a7f10 data-v-1e5a7f10></path>
                                                    </svg></div>
                                            </span>
                                            <div class="title" data-v-00eb2f76>
                                                <p class="-subtitle" data-v-00eb2f76>Baixo investimento</p>
                                                <p class="-body" data-v-00eb2f76>Investimento inicial a partir dos 16.000€ + IVA, permite-lhe ser o gestor do seu próprio negócio.</p>
                                            </div>
                                        </div>
                                        <div class="item" data-v-00eb2f76><span data-v-00eb2f76>
                                                <div class="icon -verified-shield -s24 -bistre" data-v-1e5a7f10 data-v-00eb2f76><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-1e5a7f10 data-v-1e5a7f10>
                                                        <path d="M12 1L3 5V11C3 16.55 6.84 21.74 12 23C17.16 21.74 21 16.55 21 11V5L12 1ZM10.75 16.41L7.04 12.7L8.45 11.29L10.74 13.58L16.53 7.79L17.94 9.2L10.73 16.41H10.75Z" fill="#462617" data-v-1e5a7f10 data-v-1e5a7f10></path>
                                                    </svg></div>
                                            </span>
                                            <div class="title" data-v-00eb2f76>
                                                <p class="-subtitle" data-v-00eb2f76>Alta rentabilidade</p>
                                                <p class="-body" data-v-00eb2f76>Um negócio com uma boa margem e um prazo de retorno de investimento de cerca de 2 anos.</p>
                                            </div>
                                        </div>
                                        <div class="item" data-v-00eb2f76><span data-v-00eb2f76>
                                                <div class="icon -battery-charging-full -s24 -bistre" data-v-1e5a7f10 data-v-00eb2f76><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-1e5a7f10 data-v-1e5a7f10>
                                                        <path d="M15 4H14V2H10V4H9C7.9 4 7 4.9 7 6V21C7 22.1 7.9 23 9 23H15C16.1 23 17 22.1 17 21V6C17 4.9 16.1 4 15 4ZM11 20V14.5H9L13 7V12.5H15L11 20Z" fill="#462617" data-v-1e5a7f10 data-v-1e5a7f10></path>
                                                    </svg></div>
                                            </span>
                                            <div class="title" data-v-00eb2f76>
                                                <p class="-subtitle" data-v-00eb2f76>Baixos custos fixos</p>
                                                <p class="-body" data-v-00eb2f76>Loja de venda automática sem necessidade de ter funcionários sempre presentes.</p>
                                            </div>
                                        </div>
                                        <div class="item" data-v-00eb2f76><span data-v-00eb2f76>
                                                <div class="icon -clock -s24 -bistre" data-v-1e5a7f10 data-v-00eb2f76><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-1e5a7f10 data-v-1e5a7f10>
                                                        <path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2ZM15.7 16.33L10.75 13.03V7H12.75V11.96L16.8 14.66L15.69 16.32L15.7 16.33Z" fill="#462617" data-v-1e5a7f10 data-v-1e5a7f10></path>
                                                    </svg></div>
                                            </span>
                                            <div class="title" data-v-00eb2f76>
                                                <p class="-subtitle" data-v-00eb2f76>Pouca dedicação</p>
                                                <p class="-body" data-v-00eb2f76>Necessita cerca de 2 horas diárias. Pode aproveitar o seu tempo enquanto a sua Grab&Go fatura.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="buttons-wrapper" data-v-00eb2f76><a href="https://cdn.sanity.io/files/cfdx00u9/production/346e13ea6f69fd3910699d9de1f679b801d84c2c.pdf" target="_blank" data-disabled="false" tabindex="0" class="btn-catalog button -secondary -inverted-false" data-v-7a9ee508 data-v-00eb2f76><span class="button-inner -noselect" data-v-7a9ee508><span class="background" data-v-7a9ee508></span> <span class="button-type -large -secondary -icon-none -lottie-download" data-v-7a9ee508><span class="button-icon -lottie-download" data-v-7a9ee508>
                                                        <div class="lottie-wrapper" data-v-7a9ee508></div>
                                                    </span> <!----> <span class="button-label" data-v-7a9ee508><span class="button-label-main -body" data-v-7a9ee508>
                                                            Catalogo
                                                        </span></span> <!----> <!----></span></span></a> <button data-disabled="false" tabindex="0" class="btn-franchising button -primary -inverted-true" data-v-7a9ee508 data-v-00eb2f76><span class="button-inner -noselect" data-v-7a9ee508><span class="background" data-v-7a9ee508></span> <span class="button-type -large -primary -icon-none -lottie-arrow" data-v-7a9ee508><!----> <!----> <span class="button-label" data-v-7a9ee508><span class="button-label-main -body" data-v-7a9ee508>
                                                            Pedir informações
                                                        </span></span> <span class="button-icon -lottie-arrow" data-v-7a9ee508>
                                                        <div class="lottie-wrapper" data-v-7a9ee508></div>
                                                    </span> <!----></span></span></button></div>
                                </div>
                            </div>
                        </section>
                        <section class="-business bg-texture" data-v-35b6a005 data-v-7ab4eea4>
                            <div class="row" data-v-35b6a005>
                                <div class="xxlarge-16 columns" data-v-35b6a005>
                                    <div class="title-wrapper" data-v-35b6a005>
                                        <h2 data-animation data-split class="-h1" data-v-35b6a005>Negócio na mão em 3 passos </h2> <img src="/_nuxt/image/4d44ef.auto" alt="100 bill" sizes="(max-width: 743px) 20vw, (max-width: 1023px) 30vw, 87vw" srcset="/_nuxt/image/770b60.auto 149w, /_nuxt/image/394239.auto 307w, /_nuxt/image/4d44ef.auto 1479w" lazy="" data-v-35b6a005>
                                    </div>
                                </div>
                            </div> <!----> <!---->
                        </section>
                        <section data-bgl-track="cup-group" class="-start-now" data-v-fc28b4d4 data-v-7ab4eea4><img src="/_nuxt/image/e9fe30.auto" alt="" sizes="(max-width: 743px) 70vw, 87vw" srcset="/_nuxt/image/1896fe.auto 520w, /_nuxt/image/e9fe30.auto 1479w" class="image-top" data-v-fc28b4d4>
                            <div class="row" data-v-fc28b4d4>
                                <div class="xxlarge-16 align-center" data-v-fc28b4d4>
                                    <div class="title-wrapper" data-v-fc28b4d4>
                                        <h2 class="-h1" data-v-fc28b4d4>comece já e fature daqui a 1 mês</h2> <!----> <button data-disabled="false" tabindex="0" class="button -primary -inverted-true" data-v-7a9ee508 data-v-fc28b4d4><span class="button-inner -noselect" data-v-7a9ee508><span class="background" data-v-7a9ee508></span> <span class="button-type -large -primary -icon-none -lottie-arrow" data-v-7a9ee508><!----> <!----> <span class="button-label" data-v-7a9ee508><span class="button-label-main -body" data-v-7a9ee508>
                                                            Quero ser contactado
                                                        </span></span> <span class="button-icon -lottie-arrow" data-v-7a9ee508>
                                                        <div class="lottie-wrapper" data-v-7a9ee508></div>
                                                    </span> <!----></span></span></button>
                                    </div>
                                </div>
                            </div> <img src="/_nuxt/image/e9fe30.auto" alt="" sizes="(max-width: 743px) 70vw, 87vw" srcset="/_nuxt/image/1896fe.auto 520w, /_nuxt/image/e9fe30.auto 1479w" class="image-bottom" data-v-fc28b4d4>
                        </section>
                        <section data-bgl-track="cup-section" class="-support" data-v-1539f2d0 data-v-7ab4eea4>
                            <div class="inner" data-v-1539f2d0>
                                <div class="row" data-v-1539f2d0>
                                    <div class="xxlarge-16 col align-center" data-v-1539f2d0>
                                        <p class="-caption" data-v-1539f2d0>FORNECEMOS</p>
                                        <h2 class="-h4" data-v-1539f2d0>
                                            Assistência técnica
                                        </h2>
                                        <div class="-body" data-v-1539f2d0 data-v-1539f2d0>
                                            <p data-v-1539f2d0 data-v-1539f2d0>Apoio telefónico
                                                365 dias por ano</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="row" data-v-1539f2d0>
                                    <div class="xxlarge-16 col align-center" data-v-1539f2d0>
                                        <p class="-caption" data-v-1539f2d0>Equipa</p>
                                        <h2 class="-h4" data-v-1539f2d0>
                                            Especializada
                                        </h2>
                                        <div class="-body" data-v-1539f2d0 data-v-1539f2d0>
                                            <p data-v-1539f2d0 data-v-1539f2d0>Equipa técnica especializada
                                                Disponível em todo o território nacional</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="row" data-v-1539f2d0>
                                    <div class="xxlarge-16 col align-center" data-v-1539f2d0>
                                        <p class="-caption" data-v-1539f2d0>OFERECEMOS</p>
                                        <h2 class="-h4" data-v-1539f2d0>
                                            Apoio marketing
                                        </h2>
                                        <div class="-body" data-v-1539f2d0 data-v-1539f2d0>
                                            <p data-v-1539f2d0 data-v-1539f2d0>Forte presença nas redes sociais.
                                                Loja com página própria.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="row" data-v-1539f2d0>
                                    <div class="xxlarge-16 col align-center" data-v-1539f2d0>
                                        <p class="-caption" data-v-1539f2d0>INTEGRAMOS-TE</p>
                                        <h2 class="-h4" data-v-1539f2d0>
                                            rede parceiros
                                        </h2>
                                        <div class="-body" data-v-1539f2d0 data-v-1539f2d0>
                                            <p data-v-1539f2d0 data-v-1539f2d0>Gestão do negócio
                                                Acompanhamento contínuo e vitalício</p>
                                        </div>
                                    </div>
                                </div> <!---->
                                <div data-bgl-track="cup-section-2" class="media" data-v-1539f2d0>
                                    <div class="group point-one" data-v-1539f2d0><!----> <img src="/_vercel/image?url=/fake-data-imgs/home/iphone.png&w=1700&q=100" alt="support image" data-v-1539f2d0> <img src="/_nuxt/image/c4b7ab.auto" alt="support image" sizes="(max-width: 743px) 20vw, (max-width: 1023px) 30vw, 87vw" srcset="/_nuxt/image/1ab69e.auto 149w, /_nuxt/image/9245d0.auto 307w, /_nuxt/image/c4b7ab.auto 1479w" data-v-1539f2d0> <img src="/_nuxt/image/b1dd65.auto" alt="support image" sizes="(max-width: 743px) 20vw, (max-width: 1023px) 30vw, 87vw" srcset="/_nuxt/image/2096b0.auto 149w, /_nuxt/image/8b08df.auto 307w, /_nuxt/image/b1dd65.auto 1479w" data-v-1539f2d0></div>
                                    <div class="group point-two" data-v-1539f2d0><img src="/_nuxt/image/3c56bc.auto" alt="team support image" loading="lazy" sizes="(max-width: 743px) 20vw, (max-width: 1023px) 30vw, 87vw" srcset="/_nuxt/image/1de842.auto 149w, /_nuxt/image/1f54e0.auto 307w, /_nuxt/image/3c56bc.auto 1479w" data-v-1539f2d0> <img src="/_nuxt/image/ec7120.auto" alt="team support image" loading="lazy" sizes="(max-width: 743px) 20vw, (max-width: 1023px) 30vw, 87vw" srcset="/_nuxt/image/a1b2e7.auto 149w, /_nuxt/image/a51d08.auto 307w, /_nuxt/image/ec7120.auto 1479w" data-v-1539f2d0></div>
                                    <div class="group point-three" data-v-1539f2d0><img src="/_nuxt/image/f20458.auto" alt="marketing support image" loading="lazy" sizes="(max-width: 743px) 20vw, (max-width: 1023px) 30vw, 87vw" srcset="/_nuxt/image/c43455.auto 149w, /_nuxt/image/73ffeb.auto 307w, /_nuxt/image/f20458.auto 1479w" data-v-1539f2d0> <img src="/_nuxt/image/c36668.auto" alt="marketing support image" loading="lazy" sizes="(max-width: 743px) 20vw, (max-width: 1023px) 30vw, 87vw" srcset="/_nuxt/image/611be6.auto 149w, /_nuxt/image/da014e.auto 307w, /_nuxt/image/c36668.auto 1479w" data-v-1539f2d0> <img src="/_nuxt/image/24530a.auto" alt="marketing support image" loading="lazy" sizes="(max-width: 743px) 20vw, (max-width: 1023px) 30vw, 87vw" srcset="/_nuxt/image/3fed0f.auto 149w, /_nuxt/image/bd55ee.auto 307w, /_nuxt/image/24530a.auto 1479w" data-v-1539f2d0></div>
                                    <div class="group point-four" data-v-1539f2d0><img src="/_nuxt/image/7c45a8.auto" alt="support image" loading="lazy" sizes="(max-width: 743px) 20vw, (max-width: 1023px) 30vw, 87vw" srcset="/_nuxt/image/384e47.auto 149w, /_nuxt/image/703513.auto 307w, /_nuxt/image/7c45a8.auto 1479w" data-v-1539f2d0> <img src="/_nuxt/image/f601b6.auto" alt="support image" loading="lazy" sizes="(max-width: 743px) 20vw, (max-width: 1023px) 30vw, 87vw" srcset="/_nuxt/image/b7bc5d.auto 149w, /_nuxt/image/3893c6.auto 307w, /_nuxt/image/f601b6.auto 1479w" data-v-1539f2d0> <img src="/_nuxt/image/d386f9.auto" alt="support image" loading="lazy" sizes="(max-width: 743px) 20vw, (max-width: 1023px) 30vw, 87vw" srcset="/_nuxt/image/11a4d9.auto 149w, /_nuxt/image/0d7297.auto 307w, /_nuxt/image/d386f9.auto 1479w" data-v-1539f2d0> <img src="/_nuxt/image/66cb9d.auto" alt="support image" loading="lazy" sizes="(max-width: 743px) 20vw, (max-width: 1023px) 30vw, 87vw" srcset="/_nuxt/image/488bc6.auto 149w, /_nuxt/image/8874dc.auto 307w, /_nuxt/image/66cb9d.auto 1479w" data-v-1539f2d0> <img src="/_nuxt/image/f71bf6.auto" alt="support image" loading="lazy" sizes="(max-width: 743px) 20vw, (max-width: 1023px) 30vw, 87vw" srcset="/_nuxt/image/4989aa.auto 149w, /_nuxt/image/bac80c.auto 307w, /_nuxt/image/f71bf6.auto 1479w" data-v-1539f2d0></div>
                                </div>
                            </div>
                        </section>
                        <footer data-bgl-track="cup-footer-section" class="-footer" data-v-eac4d60a data-v-7ab4eea4>
                            <div class="mobile-scene" data-v-eac4d60a><img src="/_nuxt/image/770f0d.auto" alt="Beach  scene with Grab&Go store" loading="lazy" sizes="(max-width: 1023px) 65vw, 87vw" srcset="/_nuxt/image/3ff83c.auto 665w, /_nuxt/image/770f0d.auto 1479w" data-v-eac4d60a></div>
                            <div class="row" data-v-eac4d60a><img src="/_nuxt/image/8d0fe6.auto" alt="Beach scene with Grab&Go store" loading="lazy" sizes="(max-width: 1023px) 65vw, 87vw" srcset="/_nuxt/image/166edf.auto 665w, /_nuxt/image/8d0fe6.auto 1479w" class="mobile-texture" data-v-eac4d60a>
                                <div class="xxlarge-16 col" data-v-eac4d60a>
                                    <div class="copyrights" data-v-eac4d60a><a href="/apoio-cliente" data-v-21670aeb data-v-eac4d60a><span data-v-21670aeb>
                                                <p data-v-eac4d60a>Apoio ao cliente</p>
                                            </span></a> <a href="/termos-e-condicoes" data-v-21670aeb data-v-eac4d60a><span data-v-21670aeb>
                                                <p data-v-eac4d60a>Política de privacidade</p>
                                            </span></a> <span class="phone" data-v-eac4d60a>
                                            <p data-v-eac4d60a>+351 239 090 211</p>
                                            <p data-v-eac4d60a>rede fixa nacional</p>
                                        </span></div>
                                    <div class="social" data-v-eac4d60a>
                                        <ul data-v-eac4d60a>
                                            <li data-v-eac4d60a><a href="https://www.instagram.com/grab_go/" target="_blank" rel="noopener noreferrer" aria-label="Instagram Social Media link" data-v-eac4d60a>
                                                    <p style="opacity:0;pointer-events:none;height:0;width:0" data-v-eac4d60a>Instagram Social</p> <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-eac4d60a>
                                                        <path d="M0 16C0 24.8366 7.16344 32 16 32C24.8366 32 32 24.8366 32 16C32 7.16344 24.8366 0 16 0C7.16344 0 0 7.16344 0 16Z" fill="white" data-v-eac4d60a></path>
                                                        <path d="M15.9992 9.2002C18.1992 9.2002 18.4992 9.2002 19.3992 9.2002C20.1992 9.2002 20.5992 9.4002 20.8992 9.5002C21.2992 9.7002 21.5992 9.8002 21.8992 10.1002C22.1992 10.4002 22.3992 10.7002 22.4992 11.1002C22.5992 11.4002 22.6992 11.8002 22.7992 12.6002C22.7992 13.5002 22.7992 13.7002 22.7992 16.0002C22.7992 18.3002 22.7992 18.5002 22.7992 19.4002C22.7992 20.2002 22.5992 20.6002 22.4992 20.9002C22.2992 21.3002 22.1992 21.6002 21.8992 21.9002C21.5992 22.2002 21.2992 22.4002 20.8992 22.5002C20.5992 22.6002 20.1992 22.7002 19.3992 22.8002C18.4992 22.8002 18.2992 22.8002 15.9992 22.8002C13.6992 22.8002 13.4992 22.8002 12.5992 22.8002C11.7992 22.8002 11.3992 22.6002 11.0992 22.5002C10.6992 22.3002 10.3992 22.2002 10.0992 21.9002C9.79922 21.6002 9.59922 21.3002 9.49922 20.9002C9.39922 20.6002 9.29922 20.2002 9.19922 19.4002C9.19922 18.5002 9.19922 18.3002 9.19922 16.0002C9.19922 13.7002 9.19922 13.5002 9.19922 12.6002C9.19922 11.8002 9.39922 11.4002 9.49922 11.1002C9.69922 10.7002 9.79922 10.4002 10.0992 10.1002C10.3992 9.8002 10.6992 9.6002 11.0992 9.5002C11.3992 9.4002 11.7992 9.3002 12.5992 9.2002C13.4992 9.2002 13.7992 9.2002 15.9992 9.2002ZM15.9992 7.7002C13.6992 7.7002 13.4992 7.7002 12.5992 7.7002C11.6992 7.7002 11.0992 7.9002 10.5992 8.1002C10.0992 8.3002 9.59922 8.6002 9.09922 9.1002C8.59922 9.6002 8.39922 10.0002 8.09922 10.6002C7.89922 11.1002 7.79922 11.7002 7.69922 12.6002C7.69922 13.5002 7.69922 13.8002 7.69922 16.0002C7.69922 18.3002 7.69922 18.5002 7.69922 19.4002C7.69922 20.3002 7.89922 20.9002 8.09922 21.4002C8.29922 21.9002 8.59922 22.4002 9.09922 22.9002C9.59922 23.4002 9.99922 23.6002 10.5992 23.9002C11.0992 24.1002 11.6992 24.2002 12.5992 24.3002C13.4992 24.3002 13.7992 24.3002 15.9992 24.3002C18.1992 24.3002 18.4992 24.3002 19.3992 24.3002C20.2992 24.3002 20.8992 24.1002 21.3992 23.9002C21.8992 23.7002 22.3992 23.4002 22.8992 22.9002C23.3992 22.4002 23.5992 22.0002 23.8992 21.4002C24.0992 20.9002 24.1992 20.3002 24.2992 19.4002C24.2992 18.5002 24.2992 18.2002 24.2992 16.0002C24.2992 13.8002 24.2992 13.5002 24.2992 12.6002C24.2992 11.7002 24.0992 11.1002 23.8992 10.6002C23.6992 10.1002 23.3992 9.6002 22.8992 9.1002C22.3992 8.6002 21.9992 8.4002 21.3992 8.1002C20.8992 7.9002 20.2992 7.8002 19.3992 7.7002C18.4992 7.7002 18.2992 7.7002 15.9992 7.7002Z" fill="#FF5F00" data-v-eac4d60a></path>
                                                        <path d="M15.9992 11.7002C13.5992 11.7002 11.6992 13.6002 11.6992 16.0002C11.6992 18.4002 13.5992 20.3002 15.9992 20.3002C18.3992 20.3002 20.2992 18.4002 20.2992 16.0002C20.2992 13.6002 18.3992 11.7002 15.9992 11.7002ZM15.9992 18.8002C14.4992 18.8002 13.1992 17.6002 13.1992 16.0002C13.1992 14.5002 14.3992 13.2002 15.9992 13.2002C17.4992 13.2002 18.7992 14.4002 18.7992 16.0002C18.7992 17.5002 17.4992 18.8002 15.9992 18.8002Z" fill="#FF5F00" data-v-eac4d60a></path>
                                                        <path d="M20.3992 12.6002C20.9515 12.6002 21.3992 12.1525 21.3992 11.6002C21.3992 11.0479 20.9515 10.6002 20.3992 10.6002C19.8469 10.6002 19.3992 11.0479 19.3992 11.6002C19.3992 12.1525 19.8469 12.6002 20.3992 12.6002Z" fill="#FF5F00" data-v-eac4d60a></path>
                                                    </svg>
                                                </a> <!----> <!----> <!----></li>
                                            <li data-v-eac4d60a><!----> <a href="https://www.facebook.com/grabandgo.pt/" target="_blank" rel="noopener noreferrer" aria-label="Facebook Social Media link" data-v-eac4d60a>
                                                    <p style="opacity:0;pointer-events:none;height:0;width:0" data-v-eac4d60a>Facebook Social</p> <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-eac4d60a>
                                                        <path d="M0 16C0 24.8366 7.16344 32 16 32C24.8366 32 32 24.8366 32 16C32 7.16344 24.8366 0 16 0C7.16344 0 0 7.16344 0 16Z" fill="white" data-v-eac4d60a></path>
                                                        <path d="M24 16C24 11.6 20.4 8 16 8C11.6 8 8 11.6 8 16C8 20 10.9 23.3 14.7 23.9V18.3H12.7V16H14.7V14.2C14.7 12.2 15.9 11.1 17.7 11.1C18.6 11.1 19.5 11.3 19.5 11.3V13.3H18.5C17.5 13.3 17.2 13.9 17.2 14.5V16H19.4L19 18.3H17.1V24C21.1 23.4 24 20 24 16Z" fill="#FF5F00" data-v-eac4d60a></path>
                                                    </svg>
                                                </a> <!----> <!----></li>
                                            <li data-v-eac4d60a><!----> <!----> <a href="https://www.youtube.com/@grabgo9263" target="_blank" rel="noopener noreferrer" aria-label="Youtube Social Media link" data-v-eac4d60a>
                                                    <p style="opacity:0;pointer-events:none;height:0;width:0" data-v-eac4d60a>Youtube Social</p> <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-eac4d60a>
                                                        <path d="M0 16C0 24.8366 7.16344 32 16 32C24.8366 32 32 24.8366 32 16C32 7.16344 24.8366 0 16 0C7.16344 0 0 7.16344 0 16Z" fill="white" data-v-eac4d60a></path>
                                                        <path d="M23.6 12.1004C23.4 11.4004 22.9 10.9004 22.2 10.7004C21 10.4004 15.9 10.4004 15.9 10.4004C15.9 10.4004 10.9 10.4004 9.60001 10.7004C8.90001 10.9004 8.4 11.4004 8.2 12.1004C8 13.4004 8 16.0004 8 16.0004C8 16.0004 8 18.6004 8.3 19.9004C8.5 20.6004 9 21.1004 9.7 21.3004C10.9 21.6004 16 21.6004 16 21.6004C16 21.6004 21 21.6004 22.3 21.3004C23 21.1004 23.5 20.6004 23.7 19.9004C24 18.6004 24 16.0004 24 16.0004C24 16.0004 24 13.4004 23.6 12.1004ZM14.4 18.4004V13.6004L18.6 16.0004L14.4 18.4004Z" fill="#FF5F00" data-v-eac4d60a></path>
                                                    </svg>
                                                </a> <!----></li>
                                            <li data-v-eac4d60a><!----> <!----> <!----> <a href="https://www.linkedin.com/company/grabandgopt/?viewAsMember=true" target="_blank" rel="noopener noreferrer" aria-label="linkedin Social Media link" data-v-eac4d60a>
                                                    <p style="opacity:0;pointer-events:none;height:0;width:0" data-v-eac4d60a>Linkedin Social</p> <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-eac4d60a>
                                                        <path d="M0 16C0 24.8366 7.16344 32 16 32C24.8366 32 32 24.8366 32 16C32 7.16344 24.8366 0 16 0C7.16344 0 0 7.16344 0 16Z" fill="white" data-v-eac4d60a></path>
                                                        <path d="M11.6 24H8.2V13.3H11.6V24ZM9.9 11.8C8.8 11.8 8 11 8 9.9C8 8.8 8.9 8 9.9 8C11 8 11.8 8.8 11.8 9.9C11.8 11 11 11.8 9.9 11.8ZM24 24H20.6V18.2C20.6 16.5 19.9 16 18.9 16C17.9 16 16.9 16.8 16.9 18.3V24H13.5V13.3H16.7V14.8C17 14.1 18.2 13 19.9 13C21.8 13 23.8 14.1 23.8 17.4V24H24Z" fill="#FF5F00" data-v-eac4d60a></path>
                                                    </svg>
                                                </a></li>
                                        </ul>
                                    </div>
                                    <div class="madeby" data-v-eac4d60a><a href="https://burocratik.com" target="_blank" rel="noopener noreferrer" data-v-eac4d60a>
                                            <p data-v-eac4d60a>Made by Büro</p>
                                        </a></div>
                                </div>
                            </div>
                        </footer>
                    </div>
                </div> <!---->
            </div>
        </div>
    </div>
    <script defer src="/_nuxt/static/1727281647/state.js"></script>
    <script src="/_nuxt/f0bf1a6.js" defer></script>
    <script src="/_nuxt/4cc0732.js" defer></script>
    <script src="/_nuxt/ce6b01c.js" defer></script>
    <script src="/_nuxt/dc24a1d.js" defer></script>
    <script src="/_nuxt/55a605e.js" defer></script>
    <script src="/_nuxt/2f268da.js" defer></script>
    <script src="/_nuxt/d5d45d3.js" defer></script>
    <script src="/_nuxt/b529a9c.js" defer></script>
    <script src="/_nuxt/bb5d7d3.js" defer></script>
</body>

</html>